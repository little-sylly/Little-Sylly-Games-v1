const fs = require('fs');
const r = (f) => fs.readFileSync(f, 'utf8');
const frag = `<title>Flip You For It</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Fredoka:wght@500;600;700&display=swap">
<style>
${r('style.css')}
</style>
<div id="defs"></div>
<div id="app"></div>
<div id="ov"></div>
<div id="drag"></div>
<script>
${r('engine.js')}
</script>
<script>
${r('assets.js')}
</script>
<script>
${r('app.js')}
</script>
`;
fs.writeFileSync('flip-you-for-it.html', frag);
fs.writeFileSync('test-page.html', `<!doctype html><html><head><meta charset="utf-8"></head><body>\n${frag}\n</body></html>`);
console.log('built', (frag.length / 1024).toFixed(1) + ' KB');
