/* Flip You For It — rules engine, pool generator, bots, simulation.
   Pure functions: state in, state out. No DOM. Works in the browser (window.FYFI) and Node (module.exports).
   Ranks are numbers 1..10; 10 is the S rank. Edges are top/right/bottom/left. */
(function (root) {
  'use strict';

  /* ---------- tuning constants (spec section 12: one config object) ---------- */
  const CONFIG = {
    tiers: [
      { name: 'Legend', lo: 28, hi: 33, count: 2 },
      { name: 'Veteran', lo: 22, hi: 27, count: 4 },
      { name: 'Specialist', lo: 16, hi: 21, count: 4 },
      { name: 'Wildcard', lo: 10, hi: 15, count: 2 }
    ],
    poolSize: 12,
    handSize: 5,
    sMax: 2,
    keyShare: 0.4,
    keyHigh: [7, 9],
    keyMid: [4, 6],
    wallRange: [7, 9],
    snapProb: 0.5,
    fairTolerance: 4,
    timerSeconds: 60,
    maxPoolRerolls: 3000,
    maxDealRedeals: 500,
    maxSuddenDeath: 2
  };

  const CONFIG_SNAP = { p: 0.5 };
  const DIRS = ['top', 'right', 'bottom', 'left'];
  const OPP = { top: 'bottom', right: 'left', bottom: 'top', left: 'right' };
  const S = 10;

  /* ---------- seeded random ---------- */
  function mulberry32(a) {
    a = a >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function rint(rng, lo, hi) { return lo + Math.floor(rng() * (hi - lo + 1)); }
  function shuffle(arr, rng) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      const t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const rankLabel = (v) => (v === S ? 'S' : String(v));
  const cardTotal = (c) => c.stats.top + c.stats.right + c.stats.bottom + c.stats.left;

  /* ---------- card generator ---------- */
  const TEMPLATES = {
    corner: [3, 1, 1, 3],
    spike: [1, 1, 3, 1],
    shield: [4, 4, 4, 1],
    balanced: [1, 1, 1, 1]
  };
  const ARCH_WEIGHTS = {
    Legend: [['corner', 0.35], ['shield', 0.30], ['spike', 0.20], ['balanced', 0.15]],
    Veteran: [['corner', 0.30], ['shield', 0.30], ['balanced', 0.25], ['spike', 0.15]],
    Specialist: [['spike', 0.35], ['trap', 0.30], ['corner', 0.20], ['balanced', 0.15]],
    Wildcard: [['balanced', 0.50], ['spike', 0.25], ['corner', 0.25]]
  };
  const S_PROB = { Legend: 0.5, Veteran: 0.2, Specialist: 0.3, Wildcard: 0 };

  function pickWeighted(list, rng) {
    let r = rng(), acc = 0;
    for (const [v, w] of list) { acc += w; if (r < acc) return v; }
    return list[list.length - 1][0];
  }
  function rotate(arr, k) { return arr.map((_, i) => arr[(i + k) % arr.length]); }

  function fitBudget(e, locked, lo, hi, rng) {
    let s = sum(e), guard = 0;
    while ((s < lo || s > hi) && guard++ < 120) {
      const cand = [];
      for (let i = 0; i < 4; i++) {
        if (locked[i]) continue;
        if (s < lo && e[i] < 9) cand.push(i);
        if (s > hi && e[i] > 1) cand.push(i);
      }
      if (!cand.length) return false;
      const i = cand[rint(rng, 0, cand.length - 1)];
      const d = s < lo ? 1 : -1;
      e[i] += d; s += d;
    }
    return s >= lo && s <= hi;
  }

  function buildEdges(rng, tier, keys) {
    for (let attempt = 0; attempt < 80; attempt++) {
      const T = rint(rng, tier.lo, tier.hi);
      const arch = pickWeighted(ARCH_WEIGHTS[tier.name], rng);
      let e;
      let locked = [false, false, false, false];
      if (arch === 'trap') {
        if (rng() < 0.35 && 4 * Math.round(T / 4) >= tier.lo && 4 * Math.round(T / 4) <= tier.hi) {
          const v = Math.round(T / 4);
          e = [v, v, v, v];
        } else {
          let half = Math.round(T / 2);
          if (2 * half > tier.hi) half -= 1;
          if (2 * half < tier.lo) half += 1;
          const a = rint(rng, 2, 7);
          const b = half - a;
          if (b < 1 || b > 9 || a === b) continue;
          e = rotate([a, a, b, b], rint(rng, 0, 3));
        }
        locked = [true, true, true, true];
        return { stats: toStats(e), arch };
      }
      let r = rotate(TEMPLATES[arch], rint(rng, 0, 3));
      if (rng() < 0.5) r = r.slice().reverse();
      const rs = sum(r);
      e = r.map((x) => clamp(Math.round((x * T) / rs), 1, 9));
      if (arch === 'balanced') {
        const i = rint(rng, 0, 3), j = (i + rint(rng, 1, 3)) % 4;
        if (e[i] < 9 && e[j] > 1) { e[i] += 1; e[j] -= 1; }
      }
      if (rng() < S_PROB[tier.name]) {
        let mi = 0;
        for (let i = 1; i < 4; i++) if (e[i] > e[mi]) mi = i;
        e[mi] = S; locked[mi] = true;
      }
      for (let i = 0; i < 4; i++) {
        if (locked[i] || rng() >= (CONFIG_SNAP.p)) continue;
        let best = keys[0];
        for (const k of keys) if (Math.abs(e[i] - k) < Math.abs(e[i] - best)) best = k;
        e[i] = best; locked[i] = true;
      }
      if (!fitBudget(e, locked, tier.lo, tier.hi, rng)) continue;
      if (e.filter((x) => x === S).length > CONFIG.sMax) continue;
      return { stats: toStats(e), arch };
    }
    return null;
  }
  function toStats(e) { return { top: e[0], right: e[1], bottom: e[2], left: e[3] }; }

  function counterPickOK(cards) {
    for (const c of cards) {
      if (c.tier !== 'Legend') continue;
      for (const d of DIRS) {
        const v = c.stats[d];
        if (v < 8) continue;
        const ok = cards.some((o) => o !== c && o.stats[OPP[d]] >= v);
        if (!ok) return false;
      }
    }
    return true;
  }
  function keyShareOf(cards, keys) {
    let n = 0, t = 0;
    for (const c of cards) for (const d of DIRS) { t++; if (keys.includes(c.stats[d])) n++; }
    return n / t;
  }

  /* names: array of sticker names; the pool never repeats a sticker */
  function generatePool(seed, names, cfg) {
    cfg = cfg || CONFIG;
    CONFIG_SNAP.p = cfg.snapProb === undefined ? 0.5 : cfg.snapProb;
    const rng = mulberry32(seed);
    let attempts = 0;
    while (attempts < cfg.maxPoolRerolls) {
      attempts++;
      const keys = [rint(rng, cfg.keyHigh[0], cfg.keyHigh[1]), rint(rng, cfg.keyMid[0], cfg.keyMid[1])];
      const cards = [];
      let failed = false;
      for (const tier of cfg.tiers) {
        for (let i = 0; i < tier.count; i++) {
          const b = buildEdges(rng, tier, keys);
          if (!b) { failed = true; break; }
          cards.push({ stats: b.stats, tier: tier.name, arch: b.arch });
        }
        if (failed) break;
      }
      if (failed) continue;
      if (cards.some((c) => DIRS.filter((d) => c.stats[d] === S).length > cfg.sMax)) continue;
      if (keyShareOf(cards, keys) < cfg.keyShare) continue;
      if (!counterPickOK(cards)) continue;
      const order = shuffle(cards, rng);
      const stickers = shuffle(names, rng).slice(0, order.length);
      order.forEach((c, i) => { c.id = 'c' + i; c.art = stickers[i]; });
      return { cards: order, keys, rerolls: attempts - 1 };
    }
    throw new Error('pool generator failed');
  }

  /* ---------- quick deal ---------- */
  function dealQuick(pool, rng, cfg) {
    cfg = cfg || CONFIG;
    let redeals = 0;
    for (; redeals < cfg.maxDealRedeals; redeals++) {
      const sh = shuffle(pool, rng);
      const a = sh.slice(0, cfg.handSize), b = sh.slice(cfg.handSize, cfg.handSize * 2);
      const ta = sum(a.map(cardTotal)), tb = sum(b.map(cardTotal));
      if (Math.abs(ta - tb) <= cfg.fairTolerance) return { hands: [a, b], redeals };
    }
    const sh = shuffle(pool, rng);
    return { hands: [sh.slice(0, cfg.handSize), sh.slice(cfg.handSize, cfg.handSize * 2)], redeals };
  }

  function rollWalls(rng, cfg) {
    cfg = cfg || CONFIG;
    const w = {};
    for (const d of DIRS) w[d] = rint(rng, cfg.wallRange[0], cfg.wallRange[1]);
    return w;
  }

  /* snake draft: first picker A. A B B A A B B A A B */
  function snakeOrder(firstPicker) {
    const a = firstPicker, b = 1 - firstPicker;
    return [a, b, b, a, a, b, b, a, a, b];
  }

  /* ---------- board ---------- */
  function neighbor(cell, dir) {
    const r = Math.floor(cell / 3), c = cell % 3;
    if (dir === 'top') return r > 0 ? cell - 3 : -1;
    if (dir === 'bottom') return r < 2 ? cell + 3 : -1;
    if (dir === 'left') return c > 0 ? cell - 1 : -1;
    return c < 2 ? cell + 1 : -1;
  }

  function newState(o) {
    return {
      board: new Array(9).fill(null),
      hands: [o.hands[0].slice(), o.hands[1].slice()],
      first: o.first,
      moves: 0,
      sameWall: !!o.sameWall,
      walls: o.sameWall ? o.walls : null,
      rules: o.rules || {}
    };
  }
  const turnOf = (s) => (s.moves % 2 === 0 ? s.first : 1 - s.first);
  const isOver = (s) => s.moves >= 9;

  function legalMoves(s, player) {
    const out = [];
    if (isOver(s)) return out;
    for (let cell = 0; cell < 9; cell++) {
      if (s.board[cell]) continue;
      for (const c of s.hands[player]) out.push({ cardId: c.id, cell });
    }
    return out;
  }

  /* Match test for the cap at `cell` (as if just placed): Same (always), Plus (optional rule).
     Walls only count for Same, and only when sameWall is on. */
  function matchSides(board, cell, player, s) {
    const card = board[cell].card;
    const sides = [];
    for (const d of DIRS) {
      const edge = card.stats[d];
      const n = neighbor(cell, d);
      if (n === -1) {
        if (s.sameWall && (edge === S || edge === s.walls[d])) sides.push({ dir: d, wall: true, s: edge === S, cell: -1, enemy: false });
      } else {
        const t = board[n];
        if (t && t.card.stats[OPP[d]] === edge) sides.push({ dir: d, wall: false, cell: n, enemy: t.owner !== player });
      }
    }
    const flipCells = [];
    let fired = false, wallDecisive = false, plusFired = false;
    const enemies = sides.filter((x) => !x.wall && x.enemy);
    if (sides.length >= 2 && enemies.length > 0) {
      fired = true;
      wallDecisive = sides.some((x) => x.wall) && sides.filter((x) => !x.wall).length < 2;
      for (const x of enemies) flipCells.push(x.cell);
    }
    if (s.rules && s.rules.plus) {
      const groups = {};
      for (const d of DIRS) {
        const n = neighbor(cell, d);
        if (n === -1 || !board[n]) continue;
        const sm = card.stats[d] + board[n].card.stats[OPP[d]];
        (groups[sm] = groups[sm] || []).push({ cell: n, enemy: board[n].owner !== player });
      }
      for (const k in groups) {
        const g = groups[k];
        if (g.length >= 2 && g.some((x) => x.enemy)) {
          for (const x of g) if (x.enemy && !flipCells.includes(x.cell)) { flipCells.push(x.cell); plusFired = true; }
        }
      }
      if (plusFired) fired = true;
    }
    let wallByS = false;
    if (wallDecisive) {
      const v = sides.filter((x) => !(x.wall && x.s));
      wallByS = !(v.length >= 2 && v.some((x) => !x.wall && x.enemy));
    }
    return { sides, flipCells, fired, wallDecisive, wallByS, plusFired };
  }

  /* Resolution order (spec section 6): Same, Basic, Combo.
     rules.plus      = optional Plus rule (sum match), original-Triple-Triad style.
     rules.comboSame = combo-flipped caps re-check Same/Plus (original Triple Triad). Off by default. */
  function place(s, player, cardId, cell) {
    if (isOver(s)) throw new Error('bout is over');
    if (turnOf(s) !== player) throw new Error('not that player\'s turn');
    if (s.board[cell]) throw new Error('cell taken');
    const hand = s.hands[player];
    const card = hand.find((c) => c.id === cardId);
    if (!card) throw new Error('card not in hand');

    const board = s.board.slice();
    board[cell] = { card, owner: player };
    const hands = [s.hands[0], s.hands[1]];
    hands[player] = hand.filter((c) => c.id !== cardId);

    const ev = { cell, player, cardId, flips: [], sides: [], sameFired: false, plusFired: false, wallDecisive: false, wallByS: false, wallSides: 0, sameCount: 0, basicCount: 0, comboCount: 0 };

    // 1. Same (and Plus if enabled)
    const m = matchSides(board, cell, player, s);
    ev.sides = m.sides;
    ev.wallSides = m.sides.filter((x) => x.wall).length;
    const sameQueue = [];
    if (m.fired) {
      ev.sameFired = true;
      ev.plusFired = m.plusFired;
      ev.wallDecisive = m.wallDecisive;
      ev.wallByS = m.wallByS;
      for (const c of m.flipCells) {
        board[c] = { card: board[c].card, owner: player };
        ev.flips.push({ cell: c, kind: 'same', depth: 0 });
        sameQueue.push(c);
        ev.sameCount++;
      }
    }

    // 2. Basic
    for (const d of DIRS) {
      const n = neighbor(cell, d);
      if (n === -1) continue;
      const t = board[n];
      if (!t || t.owner === player) continue;
      if (card.stats[d] > t.card.stats[OPP[d]]) {
        board[n] = { card: t.card, owner: player };
        ev.flips.push({ cell: n, kind: 'basic', depth: 0 });
        ev.basicCount++;
      }
    }

    // 3. Combo: only caps flipped by Same/Plus start a chain.
    const depth = {};
    sameQueue.forEach((c) => { depth[c] = 0; });
    const queue = sameQueue.slice();
    const comboSame = !!(s.rules && s.rules.comboSame);
    while (queue.length) {
      const c = queue.shift();
      const cc = board[c].card;
      for (const d of DIRS) {
        const n = neighbor(c, d);
        if (n === -1) continue;
        const t = board[n];
        if (!t || t.owner === player) continue;
        if (cc.stats[d] > t.card.stats[OPP[d]]) {
          board[n] = { card: t.card, owner: player };
          depth[n] = depth[c] + 1;
          ev.flips.push({ cell: n, kind: 'combo', depth: depth[n] });
          ev.comboCount++;
          queue.push(n);
        }
      }
      if (comboSame) {
        const mm = matchSides(board, c, player, s);
        if (mm.fired) {
          for (const x of mm.flipCells) {
            if (board[x].owner === player) continue;
            board[x] = { card: board[x].card, owner: player };
            depth[x] = depth[c] + 1;
            ev.flips.push({ cell: x, kind: 'combo', depth: depth[x] });
            ev.comboCount++;
            queue.push(x);
          }
        }
      }
    }

    return { state: { board, hands, first: s.first, moves: s.moves + 1, sameWall: s.sameWall, walls: s.walls, rules: s.rules }, ev };
  }

  function boardCount(s) {
    const c = [0, 0];
    for (const t of s.board) if (t) c[t.owner]++;
    return c;
  }
  /* Final score: board cards plus held cards (second placer's last card). */
  function score(s) {
    const c = boardCount(s);
    c[0] += s.hands[0].length;
    c[1] += s.hands[1].length;
    return c;
  }
  function outcome(s) {
    const sc = score(s);
    if (sc[0] >= 6) return { winner: 0, score: sc };
    if (sc[1] >= 6) return { winner: 1, score: sc };
    return { winner: -1, score: sc };
  }
  /* Sudden death: board clears, each hand is the cards in your colour, roles swap. */
  function suddenDeath(s) {
    const hands = [[], []];
    for (const t of s.board) if (t) hands[t.owner].push(t.card);
    hands[0] = hands[0].concat(s.hands[0]);
    hands[1] = hands[1].concat(s.hands[1]);
    return newState({ hands, first: 1 - s.first, sameWall: s.sameWall, walls: s.walls, rules: s.rules });
  }

  /* ---------- bots ----------
     level 0 Easy   : random legal move
     level 1 Medium : greedy (most caps on the board after this move)
     level 2 Hard   : search. Open hands -> exact minimax over the real opponent hand.
                      Hidden hands -> determinisation: sample the opponent hand from the cards it cannot see,
                      solve each sampled world, pick the move with the best average value.
     Hard never reads the opponent's hand unless ctx.open is true. */

  /* Lean copy of place() for search: same rules, no event log. Verified against place() in test.js. */
  function liteMatch(board, cell, player, s, out) {
    const card = board[cell].card, st = card.stats;
    let nSides = 0, nEnemy = 0, ec0 = -1, ec1 = -1, ec2 = -1, ec3 = -1;
    const ec = [-1, -1, -1, -1];
    for (let di = 0; di < 4; di++) {
      const d = DIRS[di], edge = st[d], n = neighbor(cell, d);
      if (n === -1) { if (s.sameWall && (edge === S || edge === s.walls[d])) nSides++; }
      else { const t = board[n]; if (t && t.card.stats[OPP[d]] === edge) { nSides++; if (t.owner !== player) { ec[di] = n; nEnemy++; } } }
    }
    out.length = 0;
    if (nSides >= 2 && nEnemy > 0) for (let i = 0; i < 4; i++) if (ec[i] !== -1) out.push(ec[i]);
    if (s.rules && s.rules.plus) {
      const sums = [0, 0, 0, 0], ns = [-1, -1, -1, -1];
      for (let di = 0; di < 4; di++) { const d = DIRS[di], n = neighbor(cell, d); if (n === -1 || !board[n]) continue; ns[di] = n; sums[di] = st[d] + board[n].card.stats[OPP[d]]; }
      for (let i = 0; i < 4; i++) {
        if (ns[i] === -1) continue;
        let cnt = 0, anyEnemy = false;
        for (let j = 0; j < 4; j++) if (ns[j] !== -1 && sums[j] === sums[i]) { cnt++; if (board[ns[j]].owner !== player) anyEnemy = true; }
        if (cnt >= 2 && anyEnemy && board[ns[i]].owner !== player && out.indexOf(ns[i]) === -1) out.push(ns[i]);
      }
    }
  }
  function placeLite(s, player, card, cell) {
    const board = s.board.slice();
    board[cell] = { card, owner: player };
    const hands = [s.hands[0], s.hands[1]];
    hands[player] = s.hands[player].filter((c) => c !== card);
    const m = [];
    liteMatch(board, cell, player, s, m);
    const queue = [];
    for (const c of m) { board[c] = { card: board[c].card, owner: player }; queue.push(c); }
    for (let di = 0; di < 4; di++) {
      const d = DIRS[di], n = neighbor(cell, d);
      if (n === -1) continue;
      const t = board[n];
      if (t && t.owner !== player && card.stats[d] > t.card.stats[OPP[d]]) board[n] = { card: t.card, owner: player };
    }
    const comboSame = !!(s.rules && s.rules.comboSame);
    const mm = [];
    for (let qi = 0; qi < queue.length; qi++) {
      const c = queue[qi], cc = board[c].card;
      for (let di = 0; di < 4; di++) {
        const d = DIRS[di], n = neighbor(c, d);
        if (n === -1) continue;
        const t = board[n];
        if (t && t.owner !== player && cc.stats[d] > t.card.stats[OPP[d]]) { board[n] = { card: t.card, owner: player }; queue.push(n); }
      }
      if (comboSame) {
        liteMatch(board, c, player, s, mm);
        for (const x of mm) if (board[x].owner !== player) { board[x] = { card: board[x].card, owner: player }; queue.push(x); }
      }
    }
    return { board, hands, first: s.first, moves: s.moves + 1, sameWall: s.sameWall, walls: s.walls, rules: s.rules };
  }

  function boardDiff(s, player) { const c = boardCount(s); return c[player] - c[1 - player]; }
  function termVal(s, me) {
    const sc = score(s), d = sc[me] - sc[1 - me];
    if (sc[me] >= 6) return 100 + d;
    if (sc[1 - me] >= 6) return -100 + d;
    return 0; // 5-5: sudden death, roughly even
  }
  function stateValue(s, player) { return isOver(s) ? termVal(s, player) : boardDiff(s, player); }
  const idNum = (id) => parseInt(String(id).slice(1), 10);
  function boardKey(s) {
    let k = '';
    for (let i = 0; i < 9; i++) { const t = s.board[i]; k += t ? String.fromCharCode(48 + idNum(t.card.id) * 2 + t.owner) : '.'; }
    return k;
  }

  /* ---- lean search engine: typed arrays, mirrors place() exactly (checked in test.js) ---- */
  const NB = new Int8Array(36);
  for (let c = 0; c < 9; c++) for (let d = 0; d < 4; d++) NB[c * 4 + d] = neighbor(c, DIRS[d]);
  function leanSetup(s, worldOpp, me) {
    // local card table: both hands + cards already on the board
    const cards = [], idx = {};
    const add = (c) => { if (!(c.id in idx)) { idx[c.id] = cards.length; cards.push(c); } return idx[c.id]; };
    const cardAt = new Int8Array(9).fill(-1), own = new Int8Array(9);
    for (let i = 0; i < 9; i++) if (s.board[i]) { cardAt[i] = add(s.board[i].card); own[i] = s.board[i].owner; }
    const hand = [0, 0];
    const hs = [s.hands[0], s.hands[1]];
    hs[1 - me] = worldOpp;
    for (let p = 0; p < 2; p++) for (const c of hs[p]) hand[p] |= 1 << add(c);
    const st = new Int8Array(cards.length * 4);
    cards.forEach((c, i) => { for (let d = 0; d < 4; d++) st[i * 4 + d] = c.stats[DIRS[d]]; });
    const idxMap = idx;
    return {
      cards, idx: idxMap, st, cardAt, own, hand, moves: s.moves, first: s.first,
      sameWall: !!s.sameWall, walls: s.sameWall ? Int8Array.from(DIRS.map((d) => s.walls[d])) : null,
      plus: !!(s.rules && s.rules.plus), comboSame: !!(s.rules && s.rules.comboSame)
    };
  }
  function leanMatch(L, cardAt, own, cell, player, flipOut) {
    const ci = cardAt[cell];
    let nSides = 0, nEnemy = 0, wallSides = 0, nFlip = 0;
    const es = [-1, -1, -1, -1];
    for (let d = 0; d < 4; d++) {
      const edge = L.st[ci * 4 + d], n = NB[cell * 4 + d];
      if (n === -1) {
        if (L.sameWall && (edge === S || edge === L.walls[d])) { nSides++; wallSides++; }
      } else if (cardAt[n] >= 0 && L.st[cardAt[n] * 4 + ((d + 2) & 3)] === edge) {
        nSides++;
        if (own[n] !== player) { nEnemy++; es[d] = n; }
      }
    }
    if (nSides >= 2 && nEnemy > 0) for (let d = 0; d < 4; d++) if (es[d] >= 0) flipOut[nFlip++] = es[d];
    if (L.plus) {
      const sm = [0, 0, 0, 0], ce = [-1, -1, -1, -1];
      for (let d = 0; d < 4; d++) {
        const n = NB[cell * 4 + d];
        if (n === -1 || cardAt[n] < 0) continue;
        sm[d] = L.st[ci * 4 + d] + L.st[cardAt[n] * 4 + ((d + 2) & 3)];
        ce[d] = n;
      }
      for (let d = 0; d < 4; d++) {
        if (ce[d] < 0) continue;
        let cnt = 0, anyEnemy = false;
        for (let e = 0; e < 4; e++) if (ce[e] >= 0 && sm[e] === sm[d]) { cnt++; if (own[ce[e]] !== player) anyEnemy = true; }
        if (cnt >= 2 && anyEnemy && own[ce[d]] !== player) {
          let dup = false;
          for (let k = 0; k < nFlip; k++) if (flipOut[k] === ce[d]) dup = true;
          if (!dup) flipOut[nFlip++] = ce[d];
        }
      }
    }
    return nFlip;
  }
  /* returns new {cardAt, own} after player places local card ci at cell */
  function leanPlace(L, cardAt0, own0, cell, ci, player) {
    const cardAt = Int8Array.from(cardAt0), own = Int8Array.from(own0);
    cardAt[cell] = ci; own[cell] = player;
    const fl = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    const nf = leanMatch(L, cardAt, own, cell, player, fl);
    const queue = [];
    for (let k = 0; k < nf; k++) { own[fl[k]] = player; queue.push(fl[k]); }
    for (let d = 0; d < 4; d++) {
      const n = NB[cell * 4 + d];
      if (n === -1 || cardAt[n] < 0 || own[n] === player) continue;
      if (L.st[ci * 4 + d] > L.st[cardAt[n] * 4 + ((d + 2) & 3)]) own[n] = player;
    }
    let qi = 0;
    while (qi < queue.length) {
      const c = queue[qi++], cc = cardAt[c];
      for (let d = 0; d < 4; d++) {
        const n = NB[c * 4 + d];
        if (n === -1 || cardAt[n] < 0 || own[n] === player) continue;
        if (L.st[cc * 4 + d] > L.st[cardAt[n] * 4 + ((d + 2) & 3)]) { own[n] = player; queue.push(n); }
      }
      if (L.comboSame) {
        const nf2 = leanMatch(L, cardAt, own, c, player, fl);
        for (let k = 0; k < nf2; k++) if (own[fl[k]] !== player) { own[fl[k]] = player; queue.push(fl[k]); }
      }
    }
    return { cardAt, own };
  }
  function leanDiff(cardAt, own, me) {
    let d = 0;
    for (let i = 0; i < 9; i++) if (cardAt[i] >= 0) d += own[i] === me ? 1 : -1;
    return d;
  }
  function leanTerm(L, cardAt, own, hand, me) {
    let m = 0, o = 0;
    for (let i = 0; i < 9; i++) if (cardAt[i] >= 0) { if (own[i] === me) m++; else o++; }
    for (let b = hand[me]; b; b &= b - 1) m++;
    for (let b = hand[1 - me]; b; b &= b - 1) o++;
    if (m >= 6) return 100 + m - o;
    if (o >= 6) return -100 + m - o;
    return 0;
  }
  const POW27 = []; { let x = 1; for (let i = 0; i < 9; i++) { POW27.push(x); x *= 27; } }
  /* alpha-beta with transposition table. Value from `me` perspective. */
  function leanAB(L, cardAt, own, hand, moves, me, depth, alpha, beta, ctx) {
    if (moves >= 9) return leanTerm(L, cardAt, own, hand, me);
    if (depth === 0) return leanDiff(cardAt, own, me);
    if (++ctx.nodes > ctx.limit) { ctx.aborted = true; return 0; }
    let key = 0;
    for (let i = 0; i < 9; i++) key += (cardAt[i] < 0 ? 0 : 1 + cardAt[i] * 2 + own[i]) * POW27[i];
    key = key * 16 + depth;
    const hit = ctx.tt.get(key);
    const a0 = alpha;
    if (hit) {
      if (hit.f === 0) return hit.v;
      if (hit.f === 1 && hit.v >= beta) return hit.v;
      if (hit.f === 2 && hit.v <= alpha) return hit.v;
    }
    const p = moves % 2 === 0 ? L.first : 1 - L.first, maxing = p === me;
    if (depth === 1 || moves === 8) {
      // bottom ply: evaluate children directly, no ordering, no recursion
      let bst = maxing ? -Infinity : Infinity;
      const nh = [hand[0], hand[1]];
      for (let cell = 0; cell < 9; cell++) {
        if (cardAt[cell] >= 0) continue;
        for (let b = hand[p]; b; b &= b - 1) {
          const ci = 31 - Math.clz32(b & -b);
          const r = leanPlace(L, cardAt, own, cell, ci, p);
          nh[0] = hand[0]; nh[1] = hand[1]; nh[p] = hand[p] & ~(1 << ci);
          const v = moves + 1 >= 9 ? leanTerm(L, r.cardAt, r.own, nh, me) : leanDiff(r.cardAt, r.own, me);
          if (maxing) { if (v > bst) bst = v; if (bst > alpha) alpha = bst; }
          else { if (v < bst) bst = v; if (bst < beta) beta = bst; }
          if (alpha >= beta) return bst;
        }
      }
      return bst;
    }
    const kids = [];
    for (let cell = 0; cell < 9; cell++) {
      if (cardAt[cell] >= 0) continue;
      for (let b = hand[p]; b; b &= b - 1) {
        const ci = 31 - Math.clz32(b & -b);
        const r = leanPlace(L, cardAt, own, cell, ci, p);
        kids.push({ r, ci, h: leanDiff(r.cardAt, r.own, me) });
      }
    }
    kids.sort(maxing ? (x, y) => y.h - x.h : (x, y) => x.h - y.h);
    let best = maxing ? -Infinity : Infinity;
    const nh = [hand[0], hand[1]];
    for (const k of kids) {
      nh[0] = hand[0]; nh[1] = hand[1]; nh[p] = hand[p] & ~(1 << k.ci);
      const v = leanAB(L, k.r.cardAt, k.r.own, nh.slice(), moves + 1, me, depth - 1, alpha, beta, ctx);
      if (ctx.aborted) return 0;
      if (maxing) { if (v > best) best = v; if (best > alpha) alpha = best; }
      else { if (v < best) best = v; if (best < beta) beta = best; }
      if (alpha >= beta) break;
    }
    ctx.tt.set(key, { v: best, f: best <= a0 ? 2 : best >= beta ? 1 : 0 });
    return best;
  }

  function combos(arr, k, cap) {
    const out = [];
    (function rec(start, cur) {
      if (out.length >= cap) return;
      if (cur.length === k) { out.push(cur.slice()); return; }
      for (let i = start; i < arr.length; i++) { cur.push(arr[i]); rec(i + 1, cur); cur.pop(); if (out.length >= cap) return; }
    })(0, []);
    return out;
  }

  /* worlds the bot must consider for the opponent's hand */
  function opponentWorlds(s, player, ctx, rng) {
    const opp = 1 - player;
    if (!ctx || ctx.open || !ctx.unseen) return [s.hands[opp]];
    const need = s.hands[opp].length, pool = ctx.unseen;
    if (pool.length <= need) return [pool.slice(0, need)];
    const n = ctx.samples || 6;
    // small enough: enumerate every possible hand
    let total = 1;
    for (let i = 0; i < need; i++) total = (total * (pool.length - i)) / (i + 1);
    if (total <= n) return combos(pool, need, n);
    const seen = new Set(), out = [];
    for (let tries = 0; out.length < n && tries < n * 6; tries++) {
      const h = shuffle(pool, rng).slice(0, need);
      const key = h.map((c) => c.id).sort().join();
      if (seen.has(key)) continue;
      seen.add(key); out.push(h);
    }
    return out;
  }

  function hardMove(s, player, rng, ctx) {
    const opp = 1 - player;
    const moves = legalMoves(s, player);
    if (moves.length === 1) return moves[0];
    const worlds = opponentWorlds(s, player, ctx, rng);
    const remaining = 9 - s.moves;
    const limit = (ctx && ctx.nodes) || 60000;
    const perWorldLimit = Math.max(2000, Math.floor(limit / worlds.length));
    const Ls = worlds.map((w) => leanSetup(s, w, player));
    // root moves in local indices (same card table for every world only if the card sets match, so build per world)
    const rootInfo = moves.map((m) => ({ m }));
    const sums = [];
    const tts = worlds.map(() => new Map());
    // greedy value for ordering / tie-break
    rootInfo.forEach((r) => { r.h = boardDiff(place(s, player, r.m.cardId, r.m.cell).state, player); });
    const idxOf = (L, id) => { for (let i = 0; i < L.cards.length; i++) if (L.cards[i].id === id) return i; return -1; };
    let bestVals = rootInfo.map((r) => r.h), solved = 0;
    for (let depth = 1; depth <= remaining; depth++) {
      const vals = new Array(rootInfo.length).fill(0);
      let ok = true;
      for (let w = 0; w < worlds.length && ok; w++) {
        const L = Ls[w];
        const wctx = { nodes: 0, limit: perWorldLimit, aborted: false, tt: tts[w] };
        for (let i = 0; i < rootInfo.length; i++) {
          const m = rootInfo[i].m;
          const ci = L.idx[m.cardId];
          const r = leanPlace(L, L.cardAt, L.own, m.cell, ci, player);
          const nh = [L.hand[0], L.hand[1]];
          nh[player] &= ~(1 << ci);
          const v = leanAB(L, r.cardAt, r.own, nh, s.moves + 1, player, depth - 1, -Infinity, Infinity, wctx);
          if (wctx.aborted) { ok = false; break; }
          vals[i] += v / worlds.length;
        }
      }
      if (!ok) break;
      bestVals = vals; solved = depth;
    }
    let bi = 0;
    for (let i = 1; i < rootInfo.length; i++) {
      const a = bestVals[i] + rootInfo[i].h * 0.001 + rng() * 1e-4, b = bestVals[bi] + rootInfo[bi].h * 0.001 + rng() * 1e-4;
      if (a > b) bi = i;
    }
    const mv = rootInfo[bi].m;
    const out = { cardId: mv.cardId, cell: mv.cell, depth: solved, worlds: worlds.length, value: bestVals[bi] };
    if (ctx && ctx.wantAll) out.all = rootInfo.map((r, i) => ({ cardId: r.m.cardId, cell: r.m.cell, v: bestVals[i] }));
    return out;
  }

  function botMove(s, player, level, rng, ctx) {
    const moves = legalMoves(s, player);
    if (!moves.length) return null;
    if (level <= 0) return moves[rint(rng, 0, moves.length - 1)];
    if (level === 1) {
      let best = null;
      for (const m of moves) {
        const v = stateValue(place(s, player, m.cardId, m.cell).state, player) + rng() * 0.01;
        if (!best || v > best.v) best = { m, v };
      }
      return best.m;
    }
    return hardMove(s, player, rng, ctx);
  }

  function botPick(available, level, rng) {
    if (level <= 0) return available[rint(rng, 0, available.length - 1)].id;
    let best = null;
    for (const c of available) {
      const mx = Math.max(c.stats.top, c.stats.right, c.stats.bottom, c.stats.left);
      const v = cardTotal(c) + (level >= 2 ? 0.35 * mx : 0) + rng() * 0.5;
      if (!best || v > best.v) best = { c, v };
    }
    return best.c.id;
  }

  /* What does this player's turn offer? Counts moves that would fire Same / a wall-decisive Same / a combo. */
  function scanTurn(s, player) {
    const r = { moves: 0, same: 0, wall: 0, wallAny: 0, combo: 0 };
    for (const m of legalMoves(s, player)) {
      const ev = place(s, player, m.cardId, m.cell).ev;
      r.moves++;
      if (ev.sameFired) r.same++;
      if (ev.wallDecisive) r.wall++;
      if (ev.sameFired && ev.wallSides > 0) r.wallAny++;
      if (ev.comboCount > 0) r.combo++;
    }
    return r;
  }

  function unseenFor(s, pool, p) {
    const own = s.hands[p].map((c) => c.id);
    return pool.filter((c) => !own.includes(c.id) && !s.board.some((t) => t && t.card.id === c.id));
  }

  /* ---------- simulation (balance lab) ----------
     opts: {mode, sameWall, levels:[a,b] | level, wallRange, rules, cfg, open (bots see hands; default false), scan}
     Only the opening round of each bout feeds the event statistics. */
  function playBout(s0, levels, rng, ctx, tally) {
    let s = s0;
    while (!isOver(s)) {
      const p = turnOf(s);
      if (ctx.scan && tally && tally.turn) tally.turn(scanTurn(s, p), s, p);
      const mctx = ctx.open ? { open: true, nodes: ctx.nodes } : { unseen: unseenFor(s, ctx.pool, p), nodes: ctx.nodes, samples: ctx.samples };
      const m = botMove(s, p, levels[p], rng, mctx);
      const r = place(s, p, m.cardId, m.cell);
      if (tally) tally.move ? tally.move(r.ev, s, p) : tally(r.ev);
      s = r.state;
    }
    return s;
  }

  function simulateBouts(opts, startSeed, count, names) {
    const acc = {
      n: 0, firstWins: 0, secondWins: 0, draws: 0, initialTies: 0, initialFirstWins: 0, initialSecondWins: 0,
      sameBouts: 0, sameEvents: 0, wallBouts: 0, wallEvents: 0, wallEventsS: 0, wallInvolved: 0, comboBouts: 0, comboEvents: 0, plusEvents: 0,
      flips: 0, placements: 0, maxChainSum: 0, poolRerolls: 0, poolsRerolled: 0, redeals: 0, dealsRedealt: 0,
      firstScoreSum: 0, deals: 0,
      turns: 0, turnsSameAvail: 0, turnsWallAvail: 0, turnsComboAvail: 0, sameAvailMoves: 0, movesScanned: 0,
      bigSwing: 0, seat0Wins: 0, seat1Wins: 0
    };
    const lv = opts.levels || [opts.level, opts.level];
    const cfg = Object.assign({}, CONFIG, opts.cfg || {});
    if (opts.wallRange) cfg.wallRange = opts.wallRange;
    const rules = opts.rules || {};
    for (let i = 0; i < count; i++) {
      const seed = (startSeed + i) >>> 0;
      const rng = mulberry32(seed ^ 0x9e3779b9);
      const poolRes = generatePool(seed, names, cfg);
      acc.poolRerolls += poolRes.rerolls;
      if (poolRes.rerolls > 0) acc.poolsRerolled++;
      const pool = poolRes.cards;
      const walls = opts.sameWall ? rollWalls(rng, cfg) : null;
      let hands, first, open;
      if (opts.mode === 'draft') {
        const firstPicker = rint(rng, 0, 1);
        first = 1 - firstPicker;
        open = true; // a draft is deducible, so the bots treat it as open
        const order = snakeOrder(firstPicker);
        const avail = pool.slice();
        hands = [[], []];
        for (const p of order) {
          const id = botPick(avail, lv[p], rng);
          const k = avail.findIndex((c) => c.id === id);
          hands[p].push(avail[k]);
          avail.splice(k, 1);
        }
      } else {
        const d = dealQuick(pool, rng, cfg);
        acc.redeals += d.redeals; acc.deals++;
        if (d.redeals > 0) acc.dealsRedealt++;
        hands = d.hands;
        first = rint(rng, 0, 1);
        open = !!opts.open;
      }
      const initialFirst = first;
      let s = newState({ hands, first, walls, sameWall: opts.sameWall, rules });
      let sameSeen = 0, wallSeen = 0, comboSeen = 0, flipsHere = 0, plusSeen = 0, wallInv = 0;
      let initial = true, winner = -2, sd = 0;
      for (;;) {
        const tally = {
          move: (ev) => {
            if (!initial) return;
            acc.placements++;
            const f = ev.flips.length;
            acc.flips += f; flipsHere = Math.max(flipsHere, f);
            if (ev.sameFired) sameSeen++;
            if (ev.plusFired) plusSeen++;
            if (ev.sameFired && ev.wallSides > 0) wallInv++;
            if (ev.wallDecisive) { wallSeen++; if (ev.wallByS) acc.wallEventsS++; }
            if (ev.comboCount > 0) comboSeen++;
            if (f >= 4) acc.bigSwing++;
          },
          turn: (sc) => {
            if (!initial) return;
            acc.turns++; acc.movesScanned += sc.moves;
            if (sc.same) acc.turnsSameAvail++;
            if (sc.wall) acc.turnsWallAvail++;
            if (sc.combo) acc.turnsComboAvail++;
            acc.sameAvailMoves += sc.same;
          }
        };
        s = playBout(s, lv, rng, { open, pool, scan: !!opts.scan, nodes: opts.nodes, samples: opts.samples }, tally);
        const o = outcome(s);
        if (initial) {
          acc.firstScoreSum += o.score[initialFirst];
          if (o.winner === -1) acc.initialTies++;
          else if (o.winner === initialFirst) acc.initialFirstWins++;
          else acc.initialSecondWins++;
          initial = false;
        }
        if (o.winner !== -1) { winner = o.winner; break; }
        if (sd >= CONFIG.maxSuddenDeath) { winner = -1; break; }
        sd++;
        s = suddenDeath(s);
        open = true;
      }
      acc.n++;
      if (winner === 0) acc.seat0Wins++; else if (winner === 1) acc.seat1Wins++;
      if (winner === -1) acc.draws++;
      else if (winner === initialFirst) acc.firstWins++;
      else acc.secondWins++;
      if (sameSeen) acc.sameBouts++;
      acc.sameEvents += sameSeen;
      acc.plusEvents += plusSeen;
      if (wallSeen) acc.wallBouts++;
      acc.wallEvents += wallSeen;
      acc.wallInvolved += wallInv;
      if (comboSeen) acc.comboBouts++;
      acc.comboEvents += comboSeen;
      acc.maxChainSum += flipsHere;
    }
    return acc;
  }

  const api = {
    CONFIG, DIRS, OPP, S, mulberry32, rint, shuffle, rankLabel, cardTotal,
    generatePool, counterPickOK, keyShareOf, dealQuick, rollWalls, snakeOrder,
    neighbor, newState, turnOf, isOver, legalMoves, place, boardCount, score, outcome, suddenDeath,
    placeLite, botMove, botPick, scanTurn, unseenFor, playBout, simulateBouts
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.FYFI = api;
})(typeof window !== 'undefined' ? window : this);
