const E = require('./engine.js');
const assert = require('assert');
let pass = 0;
function t(name, fn) { try { fn(); pass++; console.log('ok  -', name); } catch (e) { console.log('FAIL -', name, '\n    ', e.message); process.exitCode = 1; } }
const S = 10;
const C = (id, tier, top, right, bottom, left) => ({ id, art: id, tier, stats: { top, right, bottom, left } });

/* ---- Sample A from the brief ---- */
const cards = {
  NS: C('NS', 'Legend', 8, 8, 8, 5), PO: C('PO', 'Legend', S, 8, 5, 8),
  LP: C('LP', 'Veteran', 8, 8, 8, 2), BA: C('BA', 'Veteran', 8, 3, 3, 8), FS: C('FS', 'Veteran', 6, 6, 6, 5), CJ: C('CJ', 'Veteran', 3, 8, 8, 3),
  FL: C('FL', 'Specialist', 3, 4, S, 3), BL: C('BL', 'Specialist', 5, 5, 5, 5), DD: C('DD', 'Specialist', 8, 8, 2, 2), GM: C('GM', 'Specialist', S, 2, 3, 5)
};
const JACK = 0, PRIYA = 1; // Jack places first
t('Sample A: full bout gives Priya 7, Jack 3', () => {
  let s = E.newState({
    hands: [[cards.BL, cards.FL, cards.DD, cards.NS, cards.LP], [cards.PO, cards.CJ, cards.GM, cards.BA, cards.FS]],
    first: JACK, sameWall: false
  });
  const mv = [[JACK, 'BL', 3], [PRIYA, 'CJ', 6], [JACK, 'FL', 1], [PRIYA, 'BA', 8], [JACK, 'DD', 0], [PRIYA, 'GM', 4], [JACK, 'NS', 5], [PRIYA, 'PO', 2], [JACK, 'LP', 7]];
  const evs = [];
  for (const [p, id, cell] of mv) { const r = E.place(s, p, id, cell); s = r.state; evs.push(r.ev); }
  // move 6: Same flips Flawless + Bluff, combo flips Deep-Sea Deploy
  assert.strictEqual(evs[5].sameFired, true);
  assert.strictEqual(evs[5].sameCount, 2);
  assert.strictEqual(evs[5].comboCount, 1);
  assert.deepStrictEqual(evs[5].flips.map((f) => f.cell).sort(), [0, 1, 3]);
  // move 7: only a basic flip of Great Minds, no Same
  assert.strictEqual(evs[6].sameFired, false);
  assert.deepStrictEqual(evs[6].flips.map((f) => f.cell), [4]);
  assert.strictEqual(evs[6].comboCount, 0);
  // moves 8 and 9 flip nothing
  assert.strictEqual(evs[7].flips.length, 0);
  assert.strictEqual(evs[8].flips.length, 0);
  const sc = E.score(s);
  assert.deepStrictEqual([sc[JACK], sc[PRIYA]], [3, 7]);
  assert.strictEqual(E.outcome(s).winner, PRIYA);
});

/* ---- Sample B wall match ---- */
t('Sample B: Wall Match flips Natural Selection where basic alone would not', () => {
  const walls = { top: 8, right: 7, bottom: 9, left: 8 };
  const mk = (sameWall) => {
    let s = E.newState({ hands: [[cards.LP, C('x1', 'Wildcard', 1, 1, 1, 1), C('x2', 'Wildcard', 1, 1, 1, 1), C('x3', 'Wildcard', 1, 1, 1, 1), C('x4', 'Wildcard', 1, 1, 1, 1)], [cards.NS, C('y1', 'Wildcard', 1, 1, 1, 1), C('y2', 'Wildcard', 1, 1, 1, 1), C('y3', 'Wildcard', 1, 1, 1, 1), C('y4', 'Wildcard', 1, 1, 1, 1)]], first: 1, sameWall, walls });
    s = E.place(s, 1, 'NS', 4).state; // Ben (player 1) NS at centre
    return E.place(s, 0, 'LP', 1); // Mia (player 0) LP top middle
  };
  const on = mk(true);
  assert.strictEqual(on.ev.sameFired, true);
  assert.strictEqual(on.ev.wallDecisive, true);
  assert.strictEqual(on.state.board[4].owner, 0);
  const off = mk(false);
  assert.strictEqual(off.ev.sameFired, false);
  assert.strictEqual(off.state.board[4].owner, 1);
});

t('S matches any wall; two walls alone never flip', () => {
  const walls = { top: 7, right: 7, bottom: 7, left: 7 };
  let s = E.newState({ hands: [[C('a', 'Legend', S, S, 1, 1), C('f', 'Wildcard', 1, 1, 1, 1), C('g', 'Wildcard', 1, 1, 1, 1), C('h', 'Wildcard', 1, 1, 1, 1), C('i', 'Wildcard', 1, 1, 1, 1)], [C('b', 'Wildcard', 1, 1, 1, 1), C('c', 'Wildcard', 1, 1, 1, 1), C('d', 'Wildcard', 1, 1, 1, 1), C('e', 'Wildcard', 1, 1, 1, 1), C('j', 'Wildcard', 1, 1, 1, 1)]], first: 0, sameWall: true, walls });
  // top-right corner: top and right edges are S, both match the walls, no enemy -> nothing flips
  const r = E.place(s, 0, 'a', 2);
  assert.strictEqual(r.ev.sameFired, false);
  assert.strictEqual(r.ev.flips.length, 0);
});

t('S beats 9 only through basic; 9 does not match S', () => {
  let s = E.newState({ hands: [[C('p', 'Legend', 1, 1, 1, 9), C('q', 'Wildcard', 1, 1, 1, 1), C('r', 'Wildcard', 1, 1, 1, 1), C('s2', 'Wildcard', 1, 1, 1, 1), C('t2', 'Wildcard', 1, 1, 1, 1)], [C('u', 'Legend', 1, S, 1, 1), C('v', 'Wildcard', 1, 1, 1, 1), C('w', 'Wildcard', 1, 1, 1, 1), C('x', 'Wildcard', 1, 1, 1, 1), C('y', 'Wildcard', 1, 1, 1, 1)]], first: 0, sameWall: false });
  s = E.place(s, 0, 'p', 1).state; // p at cell 1 with left 9
  // u placed at cell 0: its right S faces p's left 9: S beats 9 (basic)
  const r = E.place(s, 1, 'u', 0);
  assert.strictEqual(r.ev.sameFired, false);
  assert.strictEqual(r.state.board[1].owner, 1);
});

t('S cannot be flipped by 9, only by S via Same', () => {
  let s = E.newState({ hands: [[C('p', 'Legend', 1, 1, 1, S), C('q', 'Wildcard', 5, 5, 1, 1), C('r', 'Wildcard', 1, 1, 1, 1), C('s2', 'Wildcard', 1, 1, 1, 1), C('t2', 'Wildcard', 1, 1, 1, 1)], [C('u', 'Legend', 1, 9, 1, 1), C('v', 'Wildcard', 1, 1, 1, 1), C('w', 'Wildcard', 1, 1, 1, 1), C('x', 'Wildcard', 1, 1, 1, 1), C('y', 'Wildcard', 1, 1, 1, 1)]], first: 0, sameWall: false });
  s = E.place(s, 0, 'p', 1).state; // p left S at cell 1
  const r = E.place(s, 1, 'u', 0); // u right 9 vs S: no flip
  assert.strictEqual(r.state.board[1].owner, 0);
});

t('Combo chains continue and basic flips never start a chain', () => {
  // player 1 places in the middle; Same flips cell 1 and 3; the flipped cards then flip further
  const hands0 = [C('e0', 'Wildcard', 1, 1, 1, 1), C('e1', 'Wildcard', 1, 1, 1, 1), C('e2', 'Wildcard', 1, 1, 1, 1), C('e3', 'Wildcard', 1, 1, 1, 1), C('e4', 'Wildcard', 1, 1, 1, 1)];
  const a = C('a', 'Specialist', 2, 2, 2, 2); // enemy at 1 (bottom 2)
  const b = C('b', 'Specialist', 2, 2, 2, 2); // enemy at 3 (right 2)
  const c0 = C('c0', 'Wildcard', 1, 1, 1, 1); // enemy at 0
  const d = C('d', 'Wildcard', 1, 1, 1, 1);   // enemy at 2
    const mover = C('mover', 'Legend', 2, 1, 1, 2);
  // flipped a (top 9) beats c? set specifics:
  a.stats = { top: 2, right: 8, bottom: 2, left: 8 };
  b.stats = { top: 8, right: 2, bottom: 8, left: 2 };
  c0.stats = { top: 1, right: 1, bottom: 1, left: 1 };
  d.stats = { top: 1, right: 1, bottom: 1, left: 1 };
  let s = E.newState({ hands: [[mover, hands0[0], hands0[1], hands0[2], hands0[3]], [a, b, c0, d, hands0[4]]], first: 1, sameWall: false });
  s = E.place(s, 1, 'a', 1).state;
  s = E.place(s, 0, 'e2', 8).state;
  s = E.place(s, 1, 'b', 3).state;
  s = E.place(s, 0, 'e3', 7).state;
  s = E.place(s, 1, 'c0', 0).state;
  s = E.place(s, 0, 'e0', 6).state;
  s = E.place(s, 1, 'd', 2).state;
  // board: 0:c0(P1) 1:a(P1) 2:d(P1) 3:b(P1) 6:e0(P0) 7:e3(P0) 8:e2(P0); mover into cell 4
  const r = E.place(s, 0, 'mover', 4);
  // mover top 2 vs a.bottom 2 match, left 2 vs b.right 2 match -> Same flips a and b (both P1)
  assert.strictEqual(r.ev.sameFired, true);
  assert.strictEqual(r.ev.sameCount, 2);
  // chain: a top 2 vs nothing above; a left 8 > c0.right 1 flips cell 0; a right 8 > d.left 1 flips cell 2; b bottom 8 > e0.top... e0 is P0 own so skip
  const flipped = r.ev.flips.map((f) => f.cell).sort();
  assert.deepStrictEqual(flipped, [0, 1, 2, 3]);
  assert.strictEqual(r.ev.comboCount, 2);
});

t('Sudden Death transformation on a finished bout', () => {
  const walls = { top: 7, right: 8, bottom: 9, left: 7 };
  const mkh = (pre) => [1, 2, 3, 4, 5].map((i) => C(pre + i, 'Wildcard', i, i, i, i));
  let s = E.newState({ hands: [mkh('p'), mkh('q')], first: 0, sameWall: true, walls });
  const cellsOrder = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  let pi = 1, qi = 1;
  for (let m = 0; m < 9; m++) {
    const p = E.turnOf(s);
    const id = (p === 0 ? 'p' + (pi++) : 'q' + (qi++));
    s = E.place(s, p, id, cellsOrder[m]).state;
  }
  assert.ok(E.isOver(s));
  const sc = E.score(s);
  assert.strictEqual(sc[0] + sc[1], 10);
  const sd = E.suddenDeath(s);
  assert.strictEqual(sd.first, 1);
  assert.strictEqual(sd.hands[0].length + sd.hands[1].length, 10);
  assert.strictEqual(sd.hands[0].length, sc[0]);
  assert.deepStrictEqual(sd.walls, walls);
  assert.strictEqual(sd.moves, 0);
});

/* ---- Generator ---- */
const NAMES = Array.from({ length: 21 }, (_, i) => 'Game' + i);
t('Generator: deterministic from a seed', () => {
  const a = E.generatePool(1234, NAMES), b = E.generatePool(1234, NAMES);
  assert.deepStrictEqual(a.cards, b.cards);
});

t('Generator: 3000 pools satisfy every guardrail', () => {
  let rerolls = 0, rerolled = 0;
  const tierCount = { Legend: 2, Veteran: 4, Specialist: 4, Wildcard: 2 };
  const tierRange = { Legend: [28, 33], Veteran: [22, 27], Specialist: [16, 21], Wildcard: [10, 15] };
  for (let seed = 1; seed <= 3000; seed++) {
    const p = E.generatePool(seed, NAMES);
    rerolls += p.rerolls; if (p.rerolls) rerolled++;
    assert.strictEqual(p.cards.length, 12);
    const cnt = {};
    for (const c of p.cards) {
      cnt[c.tier] = (cnt[c.tier] || 0) + 1;
      const tot = E.cardTotal(c);
      assert.ok(tot >= tierRange[c.tier][0] && tot <= tierRange[c.tier][1], `budget ${c.tier} ${tot} seed ${seed}`);
      const sCount = Object.values(c.stats).filter((v) => v === S).length;
      assert.ok(sCount <= 2);
      for (const v of Object.values(c.stats)) assert.ok(v >= 1 && v <= 10);
    }
    assert.deepStrictEqual(cnt, tierCount);
    assert.ok(E.keyShareOf(p.cards, p.keys) >= 0.4, 'key share');
    assert.ok(E.counterPickOK(p.cards), 'counter pick');
    assert.strictEqual(new Set(p.cards.map((c) => c.art)).size, 12, 'unique stickers');
  }
  console.log(`      pools rerolled: ${(100 * rerolled / 3000).toFixed(1)}%, avg rerolls ${(rerolls / 3000).toFixed(2)}`);
});

t('Quick deal: hands within tolerance, no shared cards', () => {
  for (let seed = 1; seed <= 500; seed++) {
    const p = E.generatePool(seed, NAMES);
    const d = E.dealQuick(p.cards, E.mulberry32(seed));
    const ta = d.hands[0].reduce((x, c) => x + E.cardTotal(c), 0), tb = d.hands[1].reduce((x, c) => x + E.cardTotal(c), 0);
    assert.ok(Math.abs(ta - tb) <= 4);
    const ids = d.hands[0].concat(d.hands[1]).map((c) => c.id);
    assert.strictEqual(new Set(ids).size, 10);
  }
});

t('Snake order', () => {
  assert.deepStrictEqual(E.snakeOrder(0), [0, 1, 1, 0, 0, 1, 1, 0, 0, 1]);
});

/* ---- Invariants over simulated bouts ---- */
t('Simulation: invariants hold across 600 bouts each mode', () => {
  for (const mode of ['quick', 'draft']) for (const sameWall of [true, false]) {
    const r = E.simulateBouts({ mode, sameWall, level: 1 }, 7000, 150, NAMES);
    assert.strictEqual(r.n, 150);
    assert.strictEqual(r.firstWins + r.secondWins + r.draws, 150);
  }
});

t('Bots always produce legal moves (levels 0-2)', () => {
  const rng = E.mulberry32(99);
  for (let g = 0; g < 60; g++) {
    const p = E.generatePool(g + 1, NAMES);
    const d = E.dealQuick(p.cards, rng);
    let s = E.newState({ hands: d.hands, first: g % 2, sameWall: true, walls: E.rollWalls(rng) });
    while (!E.isOver(s)) {
      const pl = E.turnOf(s);
      const lvl = g % 3;
      const own = s.hands[pl].map((c) => c.id);
      const m = E.botMove(s, pl, lvl, rng, { unseen: p.cards.filter((c) => !own.includes(c.id) && !s.board.some((t2) => t2 && t2.card.id === c.id)) });
      s = E.place(s, pl, m.cardId, m.cell).state;
    }
    assert.strictEqual(E.score(s)[0] + E.score(s)[1], 10);
  }
});


/* ---- Hard bot ---- */
function bruteValue(s, me) {
  if (E.isOver(s)) {
    const sc = E.score(s), d = sc[me] - sc[1 - me];
    return sc[me] >= 6 ? 100 + d : sc[1 - me] >= 6 ? -100 + d : 0;
  }
  const p = E.turnOf(s);
  let best = p === me ? -Infinity : Infinity;
  for (const m of E.legalMoves(s, p)) {
    const v = bruteValue(E.place(s, p, m.cardId, m.cell).state, me);
    best = p === me ? Math.max(best, v) : Math.min(best, v);
  }
  return best;
}
t('Hard bot (open hands) plays a move whose value equals the brute-force optimum, all rule variants', () => {
  const rng = E.mulberry32(4242);
  const variants = [{}, { plus: true }, { comboSame: true }, { plus: true, comboSame: true }];
  for (let g = 0; g < 24; g++) {
    const p = E.generatePool(g + 11, NAMES);
    const d = E.dealQuick(p.cards, rng);
    let s = E.newState({ hands: d.hands, first: g % 2, sameWall: g % 3 !== 0, walls: E.rollWalls(rng, { wallRange: [1, 9] }), rules: variants[g % 4] });
    // random-play to 4 caps on the board, leaving 5 plies for brute force
    while (s.moves < 4) { const pl = E.turnOf(s); const m = E.botMove(s, pl, 0, rng, {}); s = E.place(s, pl, m.cardId, m.cell).state; }
    const pl = E.turnOf(s);
    const mv = E.botMove(s, pl, 2, rng, { open: true, nodes: 5e6 });
    assert.strictEqual(mv.depth, 5, 'solved to the end');
    const chosen = bruteValue(E.place(s, pl, mv.cardId, mv.cell).state, pl);
    let best = -Infinity;
    for (const m of E.legalMoves(s, pl)) best = Math.max(best, bruteValue(E.place(s, pl, m.cardId, m.cell).state, pl));
    assert.strictEqual(chosen, best, `game ${g}`);
  }
});

t('Hard bot with hidden hands never reads the opponent hand', () => {
  const p = E.generatePool(77, NAMES);
  const d = E.dealQuick(p.cards, E.mulberry32(3));
  const base = E.newState({ hands: d.hands, first: 0, sameWall: true, walls: { top: 7, right: 8, bottom: 9, left: 7 } });
  const unseen = p.cards.filter((c) => !d.hands[0].includes(c));
  const swapped = E.newState({ hands: [d.hands[0], unseen.filter((c) => !d.hands[1].includes(c)).concat(d.hands[1]).slice(0, 5)], first: 0, sameWall: true, walls: base.walls });
  const a = E.botMove(base, 0, 2, E.mulberry32(5), { unseen, nodes: 20000 });
  const b = E.botMove(swapped, 0, 2, E.mulberry32(5), { unseen, nodes: 20000 });
  assert.deepStrictEqual([a.cardId, a.cell], [b.cardId, b.cell]);
});

t('Plus and combo-Same rules (optional, original Triple Triad)', () => {
  // Plus: placed cap right=3 next to enemy left=4 (sum 7) and below=5 next to enemy top=2 (sum 7) -> both flip
  const mk = (id, top, right, bottom, left) => C(id, 'Veteran', top, right, bottom, left);
  const centre = mk('P', 1, 3, 5, 1);
  const eR = mk('R', 1, 1, 1, 4), eD = mk('D', 2, 1, 1, 1);
  let s = E.newState({ hands: [[centre, mk('x', 1, 1, 1, 1)], [eR, eD]], first: 1, sameWall: false, rules: { plus: true } });
  s = E.place(s, 1, 'R', 5).state;
  s = E.place(s, 0, 'x', 0).state;
  s = E.place(s, 1, 'D', 7).state;
  const r = E.place(s, 0, 'P', 4);
  assert.strictEqual(r.ev.plusFired, true);
  assert.deepStrictEqual(r.ev.flips.map((f) => f.cell).sort(), [5, 7]);
  // same position without Plus: no Same, and 3<4 / 5>2 -> only the basic flip of D
  let s2 = E.newState({ hands: [[centre, mk('x', 1, 1, 1, 1)], [eR, eD]], first: 1, sameWall: false });
  s2 = E.place(s2, 1, 'R', 5).state; s2 = E.place(s2, 0, 'x', 0).state; s2 = E.place(s2, 1, 'D', 7).state;
  const r2 = E.place(s2, 0, 'P', 4);
  assert.strictEqual(r2.ev.plusFired, false);
  assert.deepStrictEqual(r2.ev.flips.map((f) => f.cell), [7]);
});

console.log(`${pass} tests passed`);
