// Prints the per-move report from the files written by playtest-move-values.js (one per bout).
// Values: +100/-100 = forced win/loss, 0 = 5-5, small numbers = board-count lead in unfinished lines.
// "perfect-info" = engine knows the bot's real hand; "hidden-info" = engine only knows what you could.
const fs = require('fs');
let rows = [];
for (let i = 1; i <= 15; i++) rows = rows.concat(JSON.parse(fs.readFileSync(__dirname + '/../data/playtest-1/move-values-bout-' + i + '.json')));
let cur = 0;
for (const r of rows) {
  if (r.bout !== cur) { cur = r.bout; console.log('\n-- bout', cur, r.humanFirst ? '(you place first)' : '(you place second)'); }
  console.log('  m' + r.m, r.card + '@' + r.cell, '| perfect-info: chose', r.vf == null ? '?' : r.vf.toFixed(0), 'best', r.bestF.toFixed(0), '(depth ' + r.depthF + ') best=' + r.bestMoveF.join(','), '| hidden-info: chose', r.vh == null ? '?' : r.vh.toFixed(1), 'best', r.bestH.toFixed(1), '(depth ' + r.depthH + ') bot-would-play', r.bestMoveH);
}
const reg = (r) => r.bestH - r.vh;
console.log('\nmoves', rows.length, '| big hidden-info regret (>=20):', rows.filter((r) => reg(r) >= 20).length);
