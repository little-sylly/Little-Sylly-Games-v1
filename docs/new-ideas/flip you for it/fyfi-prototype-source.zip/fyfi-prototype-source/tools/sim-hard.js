const E = require('../engine.js');
const names = Array.from({ length: 21 }, (_, i) => 'n' + i);
const N = +process.env.N || 100;
function row(label, o) {
  const t0 = Date.now();
  const a = E.simulateBouts(Object.assign({ mode: 'quick', sameWall: true, scan: true, nodes: 20000, samples: 4 }, o), 1000, N, names);
  const pm = (x) => (100 * x / a.placements).toFixed(1).padStart(5);
  const pb = (x) => (100 * x / a.n).toFixed(0).padStart(4);
  const pt = (x) => (100 * x / a.turns).toFixed(0).padStart(4);
  console.log(label.padEnd(36), 'Same/bout', pb(a.sameBouts) + '%', 'Same/move', pm(a.sameEvents) + '%', 'WallDec/move', pm(a.wallEvents) + '%', '(bouts ' + pb(a.wallBouts) + '%)', 'Combo/bout', pb(a.comboBouts) + '%', '| avail/turn Same', pt(a.turnsSameAvail) + '% Wall', pt(a.turnsWallAvail) + '% Combo', pt(a.turnsComboAvail) + '%', ' 1st win', (100 * a.firstWins / a.n).toFixed(0) + '%', 'tie', (100 * a.initialTies / a.n).toFixed(0) + '%', ((Date.now() - t0) / 1000).toFixed(0) + 's');
}
row('Hard v Hard, hidden, wall 7-9', { levels: [2, 2] });
row('Hard v Hard, OPEN, wall 7-9', { levels: [2, 2], open: true });
row('Hard v Hard, hidden, wall 1-9', { levels: [2, 2], wallRange: [1, 9] });
row('Hard v Hard, hidden, wall off', { levels: [2, 2], sameWall: false });
row('Hard(P0) v Medium, hidden', { levels: [2, 1] });
row('Hard(P0) v Easy, hidden', { levels: [2, 0] });
row('Hard v Hard, hidden, +Plus+comboRe', { levels: [2, 2], rules: { plus: true, comboSame: true } });
