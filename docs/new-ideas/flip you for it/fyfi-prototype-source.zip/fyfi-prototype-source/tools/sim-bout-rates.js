const E = require('../engine.js');
const NAMES = Array.from({ length: 21 }, (_, i) => 'G' + i);
for (const mode of ['quick', 'draft']) for (const sw of [true, false]) for (const level of [0, 1, 2]) {
  const n = level === 2 ? 600 : 2000;
  const t0 = Date.now();
  const r = E.simulateBouts({ mode, sameWall: sw, level }, 100000, n, NAMES);
  const pc = (x, d = r.n) => (100 * x / d).toFixed(1) + '%';
  console.log(`${mode.padEnd(5)} wall=${sw ? 'on ' : 'off'} L${level} n=${n} firstWin=${pc(r.firstWins)} secondWin=${pc(r.secondWins)} draw=${pc(r.draws)} tie5-5=${pc(r.initialTies)} same/bout=${pc(r.sameBouts)} wallDec=${pc(r.wallBouts)} combo=${pc(r.comboBouts)} avgFirstScore=${(r.firstScoreSum / r.n).toFixed(2)} poolReroll=${pc(r.poolsRerolled)} redeal=${r.deals ? pc(r.dealsRedealt, r.deals) : '-'} ${Date.now() - t0}ms`);
}
