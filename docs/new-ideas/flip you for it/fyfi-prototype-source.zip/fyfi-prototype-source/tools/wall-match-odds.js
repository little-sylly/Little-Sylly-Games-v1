const E=require('../engine.js');
const names=Array.from({length:21},(_,i)=>'n'+i);
// probability a random outer edge matches a wall, by range; and edge value histogram
for (const wr of [[7,9],[4,9],[1,9],[1,5]]) {
  const cfg=Object.assign({},E.CONFIG,{wallRange:wr});
  let hit=0,tot=0; const hist={};
  for (let seed=1;seed<=1500;seed++){
    const pool=E.generatePool(seed,names,cfg).cards, rng=E.mulberry32(seed+7), w=E.rollWalls(rng,cfg);
    for (const c of pool) for (const d of E.DIRS){ const v=c.stats[d]; hist[v]=(hist[v]||0)+1; for (const wd of E.DIRS){ tot++; if (v===w[wd]||v===10) hit++; } }
  }
  console.log(JSON.stringify(wr),'edge==wall or S: ',(100*hit/tot).toFixed(1)+'%');
  if (wr[0]===7) console.log('edge histogram', Object.entries(hist).map(([k,v])=>k+':'+(100*v/(1500*48)).toFixed(1)+'%').join(' '));
}
