const E = require('../engine.js');
const names = Array.from({ length: 21 }, (_, i) => 'n' + i);
const N = +process.env.N || 1500;
function row(label, o) {
  const t0 = Date.now();
  const a = E.simulateBouts(Object.assign({ mode: 'quick', sameWall: true, scan: true }, o), 1000, N, names);
  const pm = (x) => (100 * x / a.placements).toFixed(1).padStart(5);
  const pb = (x) => (100 * x / a.n).toFixed(0).padStart(4);
  const pt = (x) => (100 * x / a.turns).toFixed(0).padStart(4);
  console.log(label.padEnd(44),
    'Same/bout', pb(a.sameBouts) + '%', ' Same/move', pm(a.sameEvents) + '%',
    ' WallInv', pm(a.wallInvolved) + '%', ' WallDecisive', pm(a.wallEvents) + '%', '(bouts ' + pb(a.wallBouts) + '%)',
    ' Combo/bout', pb(a.comboBouts) + '%',
    '| avail/turn Same', pt(a.turnsSameAvail) + '% Wall', pt(a.turnsWallAvail) + '% Combo', pt(a.turnsComboAvail) + '%',
    ' flips/move', (a.flips / a.placements).toFixed(2), ' 1st win', (100 * a.firstWins / a.n).toFixed(0) + '%', Date.now() - t0 + 'ms');
}
const which = process.argv[2] || 'all';
const lv = (n) => ({ levels: [n, n] });
if (which === 'base' || which === 'all') {
  console.log('--- BASELINE (current rules; wall 7-9) ---');
  row('random', lv(0)); row('greedy (Medium)', lv(1));
  row('random, draft', Object.assign(lv(0), { mode: 'draft' }));
  row('greedy, draft', Object.assign(lv(1), { mode: 'draft' }));
  row('random, wall off', Object.assign(lv(0), { sameWall: false }));
  row('greedy, wall off', Object.assign(lv(1), { sameWall: false }));
}
if (which === 'wall' || which === 'all') {
  console.log('--- WALL RANGE ---');
  for (const r of [[7, 9], [5, 9], [4, 9], [3, 8], [1, 9], [1, 6], [1, 5]]) {
    row('random wall ' + r.join('-'), Object.assign(lv(0), { wallRange: r }));
    row('greedy wall ' + r.join('-'), Object.assign(lv(1), { wallRange: r }));
  }
}
if (which === 'rules' || which === 'all') {
  console.log('--- RULE VARIANTS (greedy, wall 7-9) ---');
  row('current', lv(1));
  row('+ combo re-checks Same (orig TT)', Object.assign(lv(1), { rules: { comboSame: true } }));
  row('+ Plus', Object.assign(lv(1), { rules: { plus: true } }));
  row('+ Plus + combo re-check', Object.assign(lv(1), { rules: { plus: true, comboSame: true } }));
}
if (which === 'gen' || which === 'all') {
  console.log('--- GENERATOR (greedy) ---');
  row('current (snap 50%)', lv(1));
  row('no key snapping (snap 0)', Object.assign(lv(1), { cfg: { snapProb: 0, keyShare: 0 } }));
  row('heavy snapping (snap 80%)', Object.assign(lv(1), { cfg: { snapProb: 0.8, keyShare: 0.4 } }));
  row('keys 4-6 + 4-6', Object.assign(lv(1), { cfg: { keyHigh: [4, 6] } }));
}
