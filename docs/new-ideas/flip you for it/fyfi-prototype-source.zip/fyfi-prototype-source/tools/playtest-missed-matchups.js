const E=require('../engine.js');
const fs=require('fs');
const log=JSON.parse(fs.readFileSync(__dirname+'/../data/playtest-1/human-vs-hard-log.json','utf8'));
const TIER={L:'Legend',V:'Veteran',S:'Specialist',W:'Wildcard'};
const cardOf=(s)=>{const [id,t,e]=s.split(':');const [a,b,c,d]=e.split('-').map(x=>x==='S'?10:+x);return {id,tier:TIER[t],stats:{top:a,right:b,bottom:c,left:d}};};
let bn=0,n=0,better=0,wallBetter=0;const ex=[];
let humanWall=0,botWall=0;
for (const m of log.matches) for (const b of m.bouts) for (const rd of b.rounds) {
  if (rd.sd) continue; bn++;
  const pool=b.pool.map(cardOf),byId={};pool.forEach(c=>byId[c.id]=c);
  const walls={top:b.walls[0],right:b.walls[1],bottom:b.walls[2],left:b.walls[3]};
  let s=E.newState({hands:[rd.hands[0].map(i=>byId[i]),rd.hands[1].map(i=>byId[i])],first:rd.first,sameWall:true,walls});
  rd.moves.forEach((mv,k)=>{
    if(mv.wallDec){mv.p===0?humanWall++:botWall++;}
    if(mv.p===0){
      let bestSame=null;
      for(const x of E.legalMoves(s,0)){const r=E.place(s,0,x.cardId,x.cell); if(r.ev.sameFired&&(!bestSame||r.ev.flips.length>bestSame.f))bestSame={f:r.ev.flips.length,card:x.cardId,cell:x.cell,wall:r.ev.wallDecisive,after:E.boardCount(r.state)};}
      if(bestSame){n++; if(bestSame.f>mv.flips.length){better++; if(bestSame.wall)wallBetter++; ex.push(`bout ${bn} move ${k}: could Match-Up with ${bestSame.card}@${bestSame.cell} (flips ${bestSame.f}${bestSame.wall?', needs the wall number':''}) -> board ${bestSame.after.join('-')}; you played ${mv.card}@${mv.cell} flipping ${mv.flips.length}`);}}
    }
    s=E.place(s,mv.p,mv.card,mv.cell).state;
  });
}
console.log('human turns with a Same move available:',n,'; Same flipped more caps than the move played on',better,'of them,',wallBetter,'of which depended on the wall number. Wall-decisive Same actually played: you',humanWall,'bot',botWall);
console.log(ex.join('\n'));
