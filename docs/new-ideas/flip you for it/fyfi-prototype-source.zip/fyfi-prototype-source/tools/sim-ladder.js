const E=require('../engine.js');
const names=Array.from({length:21},(_,i)=>'n'+i);
const [a,b,n,open]=[+process.argv[2],+process.argv[3],+process.argv[4],process.argv[5]==='open'];
const t0=Date.now();
const r=E.simulateBouts({mode:'quick',sameWall:true,levels:[a,b],nodes:30000,samples:4,open},5000,n,names);
const L=['Easy','Medium','Hard'];
console.log(`${L[a]} (seat A) vs ${L[b]} (seat B), ${open?'open':'hidden'} hands, ${n} bouts: A wins ${(100*r.seat0Wins/r.n).toFixed(0)}%  B wins ${(100*r.seat1Wins/r.n).toFixed(0)}%  shared draws ${(100*r.draws/r.n).toFixed(0)}%  | opening round 5-5: ${(100*r.initialTies/r.n).toFixed(0)}% | ${((Date.now()-t0)/1000).toFixed(0)}s`);
