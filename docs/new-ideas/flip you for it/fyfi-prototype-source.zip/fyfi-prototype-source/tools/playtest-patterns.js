const E=require('../engine.js');
const fs=require('fs');
const log=JSON.parse(fs.readFileSync(__dirname+'/../data/playtest-1/human-vs-hard-log.json','utf8'));
let rows=[];for(let i=1;i<=15;i++)rows=rows.concat(JSON.parse(fs.readFileSync(__dirname+'/../data/playtest-1/move-values-bout-'+i+'.json')));
const TIER={L:'Legend',V:'Veteran',S:'Specialist',W:'Wildcard'};
const cardOf=(s)=>{const [id,t,e]=s.split(':');const [a,b,c,d]=e.split('-').map(x=>x==='S'?10:+x);return {id,tier:TIER[t],stats:{top:a,right:b,bottom:c,left:d}};};
const kind=c=>[0,2,6,8].includes(c)?'corner':c===4?'centre':'edge';
let bn=0;
const crit=[], out=[];
const stat={hFlips:0,hMoves:0,bFlips:0,bMoves:0,hTot:[[],[],[],[],[]],bTot:[[],[],[],[],[]],hRank:[[],[],[],[],[]],hCell:{corner:0,edge:0,centre:0},bCell:{corner:0,edge:0,centre:0},hSame:0,bSame:0,hCombo:0,bCombo:0,bSameFlips:0,hSameFlips:0, hFirstMoveCell:{}, bFirstSwing:[]};
for (const m of log.matches) for (const b of m.bouts) for (const rd of b.rounds) {
  if (rd.sd) continue; bn++;
  const pool=b.pool.map(cardOf),byId={};pool.forEach(c=>byId[c.id]=c);
  const humanFirst=rd.first===0;
  const hand=[rd.hands[0].map(i=>byId[i]),rd.hands[1].map(i=>byId[i])];
  const tot=c=>c.stats.top+c.stats.right+c.stats.bottom+c.stats.left;
  let hn=0,bn2=0;
  let prevAfter=[0,0];
  const hrows=rows.filter(r=>r.bout===bn);
  let critDone=false;
  rd.moves.forEach((mv,k)=>{
    const c=byId[mv.card];
    const isH=mv.p===0;
    const hl=hand[mv.p].slice().sort((x,y)=>tot(y)-tot(x));
    const rank=hl.findIndex(x=>x.id===mv.card)+1; // 1 = strongest in hand at time
    hand[mv.p]=hand[mv.p].filter(x=>x.id!==mv.card);
    if(isH){stat.hMoves++;stat.hFlips+=mv.flips.length;stat.hTot[hn].push(tot(c));stat.hRank[hn].push(rank);stat.hCell[kind(mv.cell)]++;if(mv.same){stat.hSame++;stat.hSameFlips+=mv.flips.filter(f=>f[1]==='s').length;}if(mv.combo)stat.hCombo++;hn++;}
    else{stat.bMoves++;stat.bFlips+=mv.flips.length;stat.bTot[bn2].push(tot(c));stat.bCell[kind(mv.cell)]++;if(mv.same){stat.bSame++;stat.bSameFlips+=mv.flips.filter(f=>f[1]==='s').length;}if(mv.combo)stat.bCombo++;bn2++;}
    // critical: human move where perfect info drops
    if(isH){const r=hrows.find(x=>x.m===k); if(r&&!critDone&&r.bestF>-50&&r.vf<=-50){critDone=true; const nxt=rd.moves[k+1];
      crit.push({bout:bn,humanFirst,move:k,card:mv.card,cell:mv.cell,cellKind:kind(mv.cell),cardStats:c.stats,tier:c.tier,total:tot(c),rankInHand:rank,bestAlt:r.bestMoveF.join(' / '),botReply:nxt?{card:nxt.card,cell:nxt.cell,same:nxt.same,wall:nxt.wallDec,combo:nxt.combo,flips:nxt.flips.map(f=>f.join(':')).join(' '),after:nxt.after}:null});}}
  });
  out.push({bout:bn,humanFirst,final:rd.res.score,crit:critDone});
}
const avg=a=>a.length?(a.reduce((x,y)=>x+y,0)/a.length).toFixed(1):'-';
console.log('Per-move totals (card sum of 4 edges) human vs bot, by placement number');
for(let i=0;i<5;i++)console.log(' place',i+1,'human avg total',avg(stat.hTot[i]),'(avg rank in own hand, 1=strongest left:',avg(stat.hRank[i])+') | bot',avg(stat.bTot[i]));
console.log('cells: human',JSON.stringify(stat.hCell),'bot',JSON.stringify(stat.bCell));
console.log('flips/move human',(stat.hFlips/stat.hMoves).toFixed(2),'bot',(stat.bFlips/stat.bMoves).toFixed(2));
console.log('Same moves: human',stat.hSame,'/',stat.hMoves,' bot',stat.bSame,'/',stat.bMoves,' | combos human',stat.hCombo,'bot',stat.bCombo,'| same flips human',stat.hSameFlips,'bot',stat.bSameFlips);
console.log('results:',out.map(o=>`b${o.bout}${o.humanFirst?'F':'S'}:${o.final.join('-')}`).join('  '));
console.log('\nCritical moves (first human move where best play was >= draw and the chosen move lost by force):');
crit.forEach(c=>console.log(JSON.stringify(c)));
console.log('critical in',crit.length,'of',out.length,'bouts; by move index',JSON.stringify(crit.reduce((a,c)=>{a[c.move]=(a[c.move]||0)+1;return a},{})));
