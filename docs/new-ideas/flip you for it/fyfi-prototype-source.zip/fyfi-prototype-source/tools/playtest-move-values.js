const E=require('../engine.js');
const log=JSON.parse(require('fs').readFileSync(__dirname+'/../data/playtest-1/human-vs-hard-log.json','utf8'));
const TIER={L:'Legend',V:'Veteran',S:'Specialist',W:'Wildcard'};
const cardOf=(s)=>{const [id,t,e]=s.split(':');const [a,b,c,d]=e.split('-').map(x=>x==='S'?10:+x);return {id,tier:TIER[t],stats:{top:a,right:b,bottom:c,left:d}};};
const rng=E.mulberry32(7);
const rows=[];
const t0=Date.now();
let bn=0; const ONLY=+process.argv[2];
for (const m of log.matches) for (const b of m.bouts) for (const rd of b.rounds) {
  if (rd.sd) continue;
  bn++; if (bn!==ONLY) continue;
  const pool=b.pool.map(cardOf), byId={}; pool.forEach(c=>byId[c.id]=c);
  const walls={top:b.walls[0],right:b.walls[1],bottom:b.walls[2],left:b.walls[3]};
  let s=E.newState({hands:[rd.hands[0].map(i=>byId[i]),rd.hands[1].map(i=>byId[i])],first:rd.first,sameWall:true,walls});
  const humanFirst = rd.first===0;
  rd.moves.forEach((mv,k)=>{
    const p=E.turnOf(s);
    if (p!==mv.p) throw new Error('turn mismatch');
    if (p===0) {
      // perfect-information values (cheating: sees the bot's real hand) and hidden-info values (what you could know)
      const full=E.botMove(s,0,2,rng,{open:true,nodes:1500000,wantAll:true});
      const unseen=E.unseenFor(s,pool,0);
      const hid=E.botMove(s,0,2,rng,{unseen,nodes:300000,samples:8,wantAll:true});
      const get=(r)=>{const x=r.all.find(a=>a.cardId===mv.card&&a.cell===mv.cell);return x?x.v:null;};
      if(!full.all||!hid.all){ s0=null; } else {
      const bestF=Math.max(...full.all.map(a=>a.v)), bestH=Math.max(...hid.all.map(a=>a.v));
      rows.push({bout:bn,m:k,humanFirst,cell:mv.cell,card:mv.card,vf:get(full),bestF,depthF:full.depth,vh:get(hid),bestH,depthH:hid.depth,bestMoveF:full.all.filter(a=>a.v===bestF).slice(0,3).map(a=>a.cardId+'@'+a.cell),bestMoveH:`${hid.cardId}@${hid.cell}`,flips:mv.flips.length});}
    }
    const r=E.place(s,p,mv.card,mv.cell);
    const c=E.boardCount(r.state);
    if (c[0]!==mv.after[0]||c[1]!==mv.after[1]) throw new Error('replay mismatch bout '+bn+' move '+k);
    s=r.state;
  });
}
console.log('replayed',bn,'rounds ok in',Date.now()-t0,'ms');
require('fs').writeFileSync(__dirname+'/../data/playtest-1/move-values-bout-'+ONLY+'.json',JSON.stringify(rows));
