const E=require('../engine.js');
const fs=require('fs');
const log=JSON.parse(fs.readFileSync(__dirname+'/../data/playtest-1/human-vs-hard-log.json','utf8'));
const TIER={L:'Legend',V:'Veteran',S:'Specialist',W:'Wildcard'};
const cardOf=(s)=>{const [id,t,e]=s.split(':');const [a,b,c,d]=e.split('-').map(x=>x==='S'?10:+x);return {id,tier:TIER[t],stats:{top:a,right:b,bottom:c,left:d}};};
let bn=0;
const A={h:{turns:0,sameAvail:0,tookSame:0,wallAvail:0,exposeTurns:0,exposeSame:0,exposeSwing:0,sameOpts:0},b:{turns:0,sameAvail:0,tookSame:0,wallAvail:0,exposeTurns:0,exposeSame:0,exposeSwing:0,sameOpts:0}};
const lines=[];
for (const m of log.matches) for (const b of m.bouts) for (const rd of b.rounds) {
  if (rd.sd) continue; bn++;
  const pool=b.pool.map(cardOf),byId={};pool.forEach(c=>byId[c.id]=c);
  const walls={top:b.walls[0],right:b.walls[1],bottom:b.walls[2],left:b.walls[3]};
  let s=E.newState({hands:[rd.hands[0].map(i=>byId[i]),rd.hands[1].map(i=>byId[i])],first:rd.first,sameWall:true,walls});
  rd.moves.forEach((mv,k)=>{
    const p=mv.p, who=p===0?'h':'b', opp=1-p;
    const sc=E.scanTurn(s,p);
    A[who].turns++; if(sc.same>0)A[who].sameAvail++; if(sc.wall>0)A[who].wallAvail++; if(mv.same)A[who].tookSame++;
    const r=E.place(s,p,mv.card,mv.cell);
    // after my move: does the opponent (with their real hand) have a Same reply? how big is their best Same swing?
    if(!E.isOver(r.state)){
      const oppMoves=E.legalMoves(r.state,opp);
      let any=false,best=0;
      for(const om of oppMoves){const rr=E.place(r.state,opp,om.cardId,om.cell); if(rr.ev.sameFired){any=true;best=Math.max(best,rr.ev.flips.length);}}
      A[who].exposeTurns++; if(any){A[who].exposeSame++;A[who].exposeSwing+=best;}
    }
    s=r.state;
  });
}
const f=(x,d)=>(100*x/d).toFixed(0)+'%';
for(const w of ['h','b']){const a=A[w];console.log(w==='h'?'YOU':'BOT','turns',a.turns,'| Same move available on',f(a.sameAvail,a.turns),'of turns, took it',a.tookSame,'times | wall-Same available',f(a.wallAvail,a.turns),'| after this side moved, opponent had a Same reply',f(a.exposeSame,a.exposeTurns),'of the time (avg best swing',(a.exposeSame?a.exposeSwing/a.exposeSame:0).toFixed(1),'caps)');}
