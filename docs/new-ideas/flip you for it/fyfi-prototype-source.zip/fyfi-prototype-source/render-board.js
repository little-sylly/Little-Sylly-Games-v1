const { JSDOM } = require('jsdom');
const fs = require('fs');
const { Resvg } = require('@resvg/resvg-js');
const dom = new JSDOM(fs.readFileSync('test-page.html', 'utf8'), { runScripts: 'dangerously', url: 'https://example.test/' });
const w = dom.window, A = w.FYFI_ASSETS;
const walls = { top: 7, right: 9, bottom: 8, left: 9 };
const chalk0 = w.FYFI_APP.chalkSVG(walls).replace('<svg class="chalk"', '<svg x="0" y="0" width="600" height="600"');
const mk = (id, art, tier, t, r, b, l) => ({ id, art, tier, stats: { top: t, right: r, bottom: b, left: l } });
const placed = [
  [0, mk('a', 'Cookie Jar', 'Veteran', 8, 5, 3, 7), 0], [1, mk('b', 'Fruit Salad', 'Legend', 10, 7, 3, 8), 1],
  [4, mk('c', 'Cold Shoulder', 'Specialist', 9, 2, 6, 4), 0], [5, mk('d', 'Natural Selection', 'Veteran', 5, 5, 5, 5), 1],
  [6, mk('e', 'Flip You For It', 'Legend', 4, 7, 2, 6), 1], [7, mk('f', 'Fruit Salad', 'Specialist', 6, 6, 6, 5), 0]
];
let caps = '';
placed.forEach(([i, c, o]) => {
  const col = i % 3, row = Math.floor(i / 3), cell = 0.24 * 600;
  const size = cell * 0.92, x = 0.14 * 600 + col * cell + (cell - size) / 2, y = 0.14 * 600 + row * cell + (cell - size) / 2;
  caps += A.capSVG(c, o).replace('<svg ', `<svg x="${x}" y="${y}" width="${size}" height="${size}" `);
});
const css = fs.readFileSync('style.css', 'utf8');
const capCss = css.split('\n').filter((l) => /^\s*\.cap[ .{]/.test(l)).join('\n');
const defs = A.defsHTML().replace(/<svg [^>]*>/, '<g>').replace('</svg>', '</g>');
for (const [name, bg, chalkCol, speck] of [['cement', '#444446', '#f7f6f3', 'flood-color="#ffffff" flood-opacity="0.55"'], ['pavement', '#cfcbc6', '#3f3b38', 'flood-color="#282421" flood-opacity="0.35"']]) {
  const c2 = chalk0.replace('style="flood-color:var(--speck)"', speck);
  const out = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><style>${capCss}\n.chalk-stroke{stroke:${chalkCol}}.chalk-fill{fill:${chalkCol}}.wallnum{font-family:sans-serif;font-weight:bold}.digit{font-family:sans-serif;font-weight:bold}</style><rect width="600" height="600" rx="40" fill="${bg}"/>${defs}${c2}${caps}</svg>`;
  fs.writeFileSync(`board-${name}.svg`, out);
  fs.writeFileSync(`board-${name}.png`, new Resvg(out, { font: { loadSystemFonts: true, defaultFontFamily: 'sans-serif' }, fitTo: { mode: 'width', value: 600 } }).render().asPng());
}
console.log('ok'); process.exit(0);
