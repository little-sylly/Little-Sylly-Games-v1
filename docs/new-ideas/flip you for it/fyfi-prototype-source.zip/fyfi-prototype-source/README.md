# Flip You For It: prototype source (alpha 2)

Little Sylly Games, game 21. A 2-player, Triple Triad-inspired cap-flipping game on a 3x3 board.
This folder is the playable alpha: rules engine, three bot levels, UI, tests, balance tools and the data behind the brief.

Plain JavaScript, no framework, no runtime dependencies. `jsdom` and `@resvg/resvg-js` are used only by the test and preview scripts.

## What's here

| Path | What it is |
| --- | --- |
| `engine.js` | Rules, card-pool generator, quick-deal, walls, Same / Plus / Combo / Chain, Sudden Death, bots, simulator. Pure functions, no DOM. Runs in the browser (`window.FYFI`) and in Node (`module.exports`). Tuning constants are in `CONFIG` at the top. |
| `assets.js` | Cap renderer (`capSVG`), placeholder sticker art, generated sound effects. Real sticker PNGs replace `ART` here. |
| `app.js` | The whole UI: home and settings, coin toss, package choice, draft, play screen, hand-over gates, bot turns, result overlays, game log, "Lab" screen. |
| `style.css` | Theme tokens (light and dark), board, caps, layout, animation. |
| `build.js` | Concatenates the four files above into one artifact fragment (`flip-you-for-it.html`) and a full test page (`test-page.html`). |
| `flip-you-for-it.built.html` | A pre-built copy of the artifact, so you can open the game without building anything. |
| `test.js` | 16 engine tests: the resolution order, the worked examples from the brief, walls, Plus, Chain, scoring, Sudden Death, brute-force solver check, hidden-hand check. |
| `smoke.js` | Plays 6 full sessions in a headless browser (jsdom) and checks the game log. |
| `render-cap.js`, `render-board.js` | Make PNG previews of the caps and the board (need `@resvg/resvg-js`). |
| `tools/` | Balance simulations and the playtest analysis scripts (see below). |
| `data/simulations/` | Saved output of the simulations quoted in the brief (section 19, section 22). |
| `data/playtest-1/` | The exported human-vs-Hard log (8 matches, 15 bouts) and the analysis of it. |

## Run it

```
npm install          # only needed for test.js, smoke.js and the render scripts
node build.js        # writes flip-you-for-it.html and test-page.html
node test.js         # 16 engine tests, no dependencies
node smoke.js        # needs jsdom and a fresh node build.js first
```

To play without building: open `flip-you-for-it.built.html` in a browser (it is a fragment with no doctype, written for the artifact host, but browsers render it). It needs internet for two Google Fonts only; without them it falls back to system fonts. `test-page.html` (made by `build.js`) is the same game wrapped in a full HTML page.

The two preview scripts (`render-cap.js`, `render-board.js`) write PNG and SVG files into the folder you run them from; run them from the package root.

To republish as an artifact, publish the `flip-you-for-it.html` that `build.js` writes.

## Where things are in the code

**engine.js** (908 lines)
- `CONFIG`: tiers, pool size, key-number share, wall range, fair-deal tolerance, timer, Sudden Death limit.
- `generatePool`, `dealQuick`, `rollWalls`, `snakeOrder`: set-up.
- `matchSides`, `place`: the resolution order (Same, then Basic, then Combo). `place` returns the flip events with kind and depth, which the UI uses to animate.
- Rules switches live in `state.rules`: `plus` (sum match) and `comboSame` (Chain Match). Both default off.
- `suddenDeath`, `score`, `outcome`: 5-5 handling and scoring.
- `placeLite` and the `lean*` functions: a fast copy of the rules for the Hard bot's search. `test.js` checks it against the full rules.
- `hardMove`, `botMove`, `botPick`, `unseenFor`: the bots. `botMove(state, player, level, rng, ctx)` takes level 0 Easy, 1 Medium, 2 Hard. `ctx` is `{open:true}` when the bot may see your hand, or `{unseen, samples, nodes}` when hidden.
- `playBout`, `simulateBouts`: bot-vs-bot games with per-move statistics.

**app.js** (890 lines)
- `DEF`: default settings (stored in `localStorage` under `fyfi-alpha`).
- Game log: `logMatchStart`, `logBoutStart`, `logMove`, `logSummary`, `logExportText` (stored under `fyfi-log`, last 40 matches).
- Screens: `homeHTML`, `tossHTML`, `packageHTML`, `draftHTML`, `playHTML`, `finalHTML`, `labHTML`, overlays.
- Flow: `startMatch`, `startBout`, `beginTurn`, `botThink`, `doPick`, `doPlace`, `animateFlips`, `finishBout`, `startSD`.
- `window.FYFI_APP` exposes the match state and helpers for tests and preview scripts.

## The tools folder

Run these from inside `tools/` (`cd tools`, then `node <file>`). They read `../engine.js` and print to the console; the files in `data/` are saved copies of that output (made with `> file.txt`), except `playtest-move-values.js`, which writes its own JSON.

| Script | Question it answers | Saved output |
| --- | --- | --- |
| `sim-variants.js` (set `N=1500`) | How often do Same, Same Wall and Combo happen, and who wins, with each rule or generator variant (Medium vs Easy)? | `data/simulations/variants-*.txt` |
| `sim-hard.js` | Hard vs Hard (set `N=100` for the bout count): first-placer win rate, 5-5 rate. | `hard-vs-hard.txt` |
| `sim-ladder.js A B N [open]` | Level A (0 Easy, 1 Medium, 2 Hard) in seat A vs level B in seat B over N bouts, e.g. `node sim-ladder.js 2 1 150`. | `ladder.txt` |
| `sim-bout-rates.js` | Per-settings bout rates for every bot level (slow: Hard runs 600 bouts per row). | none (prints) |
| `wall-match-odds.js` | Chance a given wall value can be matched by a random edge, for each wall range. | `wall-match-odds.txt` |
| `playtest-move-values.js <bout 1-15>` | Re-plays one logged bout and scores every human move against the best move, with and without knowing the bot's hand. Writes `data/playtest-1/move-values-bout-N.json`. | `data/playtest-1/` |
| `playtest-move-values-report.js` | Turns the 15 move-value files into the per-move report. | `analysis-move-values.txt` |
| `playtest-patterns.js`, `playtest-exposure.js`, `playtest-missed-matchups.js` | Patterns in the human's play: opening choices, how often a cap was left exposed, missed Same chances. | `analysis-*.txt` |

To run the analysis for a new log, replace `data/playtest-1/human-vs-hard-log.json` (or copy the folder to `playtest-2` and edit the path at the top of each script). `playtest-move-values.js` is slow for Hard; run the bouts in parallel, one process per bout number.

## Known gaps (details in brief sections 19 and 22)

- Stickers are placeholder drawings. The cap only needs a `<symbol id="st-<slug>">` per name.
- Single-device only: no multiplayer lobby (MDLM), no networking. Pass-the-phone with gates and vs-bot are in.
- Quick Deal information gap: the Hard bot knows the 12-cap pool, and the human is not shown it.
- No whole-match simulation yet (best of 3/5 with Sudden Death), no tutorial, hint system is not built.
