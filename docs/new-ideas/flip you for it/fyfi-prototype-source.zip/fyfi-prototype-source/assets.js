/* Placeholder sticker art, cap renderer and sound. Real sticker PNGs can replace STICKER_ART later:
   the cap only needs a <symbol id="st-<slug>"> (or an <image>) drawn in a 100x100 box. */
(function () {
  'use strict';
  const E = window.FYFI;

  const STICKER_NAMES = ['Like I\'m Five', 'Great Minds', 'Secret Signals', 'Just Enough Cooks', 'You Get It?', 'Late to the Party',
    'Natural Selection', 'Deep-Sea Deploy', 'Group Therapy', 'The Bluff', 'Bailed', 'Pass', 'Net-Trace', 'Fruit Salad',
    'Counting Sheep', 'Flawless', 'Pecking Order', 'Cookie Jar', 'Cold Shoulder', 'Honeycomb Hills', 'Flip You For It'];
  const slug = (n) => n.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

  /* Each drawing sits in a 100x100 box, roughly 70 units across. The white outline and shadow come from a shared filter. */
  const ART = {
    'like-i-m-five': '<rect x="26" y="52" width="48" height="30" rx="5" fill="#f87171"/><rect x="34" y="22" width="34" height="30" rx="5" fill="#fbbf24"/><circle cx="46" cy="37" r="4" fill="#fff"/><circle cx="58" cy="37" r="4" fill="#fff"/><circle cx="38" cy="67" r="4" fill="#fff"/><circle cx="50" cy="67" r="4" fill="#fff"/><circle cx="62" cy="67" r="4" fill="#fff"/>',
    'great-minds': '<circle cx="50" cy="42" r="25" fill="#fde047" stroke="#ca8a04" stroke-width="3"/><rect x="41" y="64" width="18" height="13" rx="3" fill="#a8a29e"/><rect x="43" y="78" width="14" height="7" rx="3" fill="#78716c"/><path d="M42 48 L46 38 L50 46 L54 38 L58 48" fill="none" stroke="#b45309" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>',
    'secret-signals': '<path d="M26 58 A34 34 0 0 1 74 58" fill="none" stroke="#8b5cf6" stroke-width="7" stroke-linecap="round"/><path d="M14 46 A50 50 0 0 1 86 46" fill="none" stroke="#a78bfa" stroke-width="7" stroke-linecap="round"/><circle cx="50" cy="68" r="10" fill="#7c3aed"/><rect x="46" y="70" width="8" height="16" rx="3" fill="#7c3aed"/>',
    'just-enough-cooks': '<path d="M38 26 q-8 -9 0 -16 M56 26 q-8 -9 0 -16" fill="none" stroke="#cbd5e1" stroke-width="5" stroke-linecap="round"/><rect x="22" y="44" width="56" height="36" rx="12" fill="#94a3b8"/><rect x="18" y="36" width="64" height="12" rx="6" fill="#64748b"/><circle cx="16" cy="60" r="6" fill="#64748b"/><circle cx="84" cy="60" r="6" fill="#64748b"/>',
    'you-get-it': '<ellipse cx="50" cy="44" rx="34" ry="25" fill="#34d399"/><polygon points="34,62 28,82 56,66" fill="#34d399"/><text x="50" y="58" font-size="42" font-weight="800" text-anchor="middle" fill="#fff" font-family="Fredoka, system-ui, sans-serif">?</text>',
    'late-to-the-party': '<polygon points="50,14 22,82 78,82" fill="#f472b6"/><path d="M36 54 L64 54 M30 68 L70 68" stroke="#fde047" stroke-width="5"/><circle cx="50" cy="14" r="7" fill="#fde047"/><circle cx="46" cy="40" r="3.5" fill="#fff"/><circle cx="56" cy="46" r="3.5" fill="#fff"/>',
    'natural-selection': '<path d="M14 54 A36 34 0 0 1 86 54 Z" fill="#ef4444"/><rect x="39" y="54" width="22" height="28" rx="9" fill="#fef3c7"/><circle cx="34" cy="42" r="6" fill="#fff"/><circle cx="52" cy="32" r="5.5" fill="#fff"/><circle cx="68" cy="44" r="6.5" fill="#fff"/>',
    'deep-sea-deploy': '<ellipse cx="46" cy="50" rx="30" ry="20" fill="#38bdf8"/><polygon points="72,50 92,32 92,68" fill="#0ea5e9"/><circle cx="34" cy="45" r="5" fill="#fff"/><circle cx="33" cy="45" r="2.4" fill="#0c4a6e"/><path d="M50 36 Q56 50 50 64" fill="none" stroke="#0284c7" stroke-width="3" stroke-linecap="round"/>',
    'group-therapy': '<path d="M50 84 C16 60 10 38 26 26 C38 18 48 24 50 33 C52 24 62 18 74 26 C90 38 84 60 50 84 Z" fill="#fb7185"/><path d="M30 34 q6 -6 12 -2" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" opacity="0.7"/>',
    'the-bluff': '<g transform="rotate(12 50 50)"><rect x="27" y="14" width="46" height="66" rx="7" fill="#f5f3ff" stroke="#6d28d9" stroke-width="4"/><text x="50" y="60" font-size="40" font-weight="800" text-anchor="middle" fill="#6d28d9" font-family="Fredoka, system-ui, sans-serif">?</text></g>',
    'bailed': '<path d="M26 36 L74 36 L66 82 L34 82 Z" fill="#60a5fa"/><ellipse cx="50" cy="36" rx="24" ry="7" fill="#93c5fd"/><path d="M28 36 Q50 4 72 36" fill="none" stroke="#1d4ed8" stroke-width="4"/><path d="M34 58 q8 6 16 0 q8 -6 16 0" fill="none" stroke="#bfdbfe" stroke-width="4" stroke-linecap="round"/>',
    'pass': '<polygon points="14,38 54,38 54,20 88,50 54,80 54,62 14,62" fill="#f59e0b" stroke="#b45309" stroke-width="3" stroke-linejoin="round"/>',
    'net-trace': '<path d="M24 68 L50 28 L76 68 Z" fill="none" stroke="#0d9488" stroke-width="5" stroke-linejoin="round"/><circle cx="24" cy="68" r="10" fill="#14b8a6" stroke="#0f766e" stroke-width="3"/><circle cx="50" cy="28" r="10" fill="#14b8a6" stroke="#0f766e" stroke-width="3"/><circle cx="76" cy="68" r="10" fill="#14b8a6" stroke="#0f766e" stroke-width="3"/>',
    'fruit-salad': '<path d="M20 26 Q26 80 80 78 Q86 62 70 63 Q44 58 36 24 Z" fill="#fde047" stroke="#ca8a04" stroke-width="3" stroke-linejoin="round"/><rect x="16" y="18" width="12" height="10" rx="3" fill="#78350f"/>',
    'counting-sheep': '<rect x="34" y="68" width="6" height="16" rx="3" fill="#44403c"/><rect x="58" y="68" width="6" height="16" rx="3" fill="#44403c"/><circle cx="34" cy="50" r="16" fill="#f5f5f4" stroke="#a8a29e" stroke-width="2"/><circle cx="50" cy="42" r="18" fill="#f5f5f4" stroke="#a8a29e" stroke-width="2"/><circle cx="64" cy="52" r="15" fill="#f5f5f4" stroke="#a8a29e" stroke-width="2"/><circle cx="48" cy="60" r="16" fill="#f5f5f4" stroke="#a8a29e" stroke-width="2"/><ellipse cx="80" cy="50" rx="9" ry="11" fill="#44403c"/><circle cx="82" cy="47" r="2" fill="#fff"/>',
    'flawless': '<polygon points="50,16 80,40 50,86 20,40" fill="#22d3ee" stroke="#0e7490" stroke-width="3" stroke-linejoin="round"/><path d="M20 40 H80 M50 16 L38 40 L50 86 L62 40 Z" fill="none" stroke="#a5f3fc" stroke-width="3" stroke-linejoin="round"/>',
    'pecking-order': '<circle cx="48" cy="52" r="28" fill="#fde047" stroke="#ca8a04" stroke-width="3"/><polygon points="74,50 90,57 74,64" fill="#f97316"/><circle cx="58" cy="44" r="3.6" fill="#1c1917"/><path d="M36 58 q10 14 24 4" fill="none" stroke="#ca8a04" stroke-width="3.4" stroke-linecap="round"/><circle cx="42" cy="22" r="5" fill="#ef4444"/><circle cx="52" cy="20" r="5" fill="#ef4444"/>',
    'cookie-jar': '<circle cx="50" cy="50" r="31" fill="#d4a15f" stroke="#8a5a2b" stroke-width="3"/><ellipse cx="38" cy="38" rx="5.5" ry="4.5" fill="#5b3a1e"/><ellipse cx="60" cy="34" rx="5" ry="4" fill="#5b3a1e"/><ellipse cx="66" cy="54" rx="5.5" ry="4.5" fill="#5b3a1e"/><ellipse cx="44" cy="62" rx="5.5" ry="4.5" fill="#5b3a1e"/><ellipse cx="30" cy="54" rx="4.5" ry="3.8" fill="#5b3a1e"/><ellipse cx="54" cy="48" rx="4" ry="3.4" fill="#5b3a1e"/>',
    'cold-shoulder': '<ellipse cx="50" cy="52" rx="25" ry="32" fill="#64748b"/><ellipse cx="50" cy="58" rx="16" ry="23" fill="#f1f5f9"/><polygon points="50,40 43,46 57,46" fill="#f97316"/><circle cx="42" cy="36" r="3" fill="#fff"/><circle cx="58" cy="36" r="3" fill="#fff"/><circle cx="42" cy="36" r="1.4" fill="#1c1917"/><circle cx="58" cy="36" r="1.4" fill="#1c1917"/><ellipse cx="40" cy="86" rx="9" ry="4" fill="#f97316"/><ellipse cx="60" cy="86" rx="9" ry="4" fill="#f97316"/>',
    'honeycomb-hills': '<polygon points="50,14 80,31 80,67 50,84 20,67 20,31" fill="#fbbf24" stroke="#b45309" stroke-width="3" stroke-linejoin="round"/><polygon points="50,32 65,41 65,59 50,68 35,59 35,41" fill="#fde68a" stroke="#b45309" stroke-width="2.4" stroke-linejoin="round"/>',
    'flip-you-for-it': '<circle cx="50" cy="50" r="31" fill="#2563eb"/><path d="M50 19 A31 31 0 0 1 50 81 Z" fill="#f97316"/><circle cx="50" cy="50" r="13" fill="#fff"/><path d="M42 50 L50 42 L58 50 L50 58 Z" fill="#fbbf24"/>'
  };

  const hash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };

  /* ---------- shared defs: gradients, clip, sticker outline, sticker symbols ---------- */
  function defsHTML() {
    const syms = STICKER_NAMES.map((n) => {
      const key = slug(n);
      return `<symbol id="st-${key}" viewBox="0 0 100 100"><g filter="url(#stk)">${ART[key] || ''}</g></symbol>`;
    }).join('');
    const rad = (id, a, b, c) => `<radialGradient id="${id}" cx="0.5" cy="0.42" r="0.62"><stop offset="0" stop-color="${a}"/><stop offset="0.55" stop-color="${b}"/><stop offset="1" stop-color="${c}"/></radialGradient>`;
    const fade = (id, rgb) => `<radialGradient id="${id}" cx="0.5" cy="0.5" r="0.5"><stop offset="0.64" stop-color="rgb(${rgb})" stop-opacity="0"/><stop offset="1" stop-color="rgb(${rgb})" stop-opacity="0.55"/></radialGradient>`;
    return `<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs>
      ${rad('faceP0', '#7ab0ff', '#2563eb', '#1d4ed8')}${rad('faceP1', '#ffc48a', '#f97316', '#ea580c')}${rad('faceN', '#e7e5e4', '#b4aea8', '#8b847d')}
      ${fade('fadeP0', '30,58,138')}${fade('fadeP1', '194,65,12')}${fade('fadeN', '97,90,85')}
      <linearGradient id="holo" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f9a8d4"/><stop offset="0.25" stop-color="#fde68a"/><stop offset="0.5" stop-color="#86efac"/><stop offset="0.75" stop-color="#7dd3fc"/><stop offset="1" stop-color="#c4b5fd"/></linearGradient>
      <linearGradient id="chrome" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f5f5f4"/><stop offset="0.3" stop-color="#9ca3af"/><stop offset="0.55" stop-color="#e5e7eb"/><stop offset="0.8" stop-color="#6b7280"/><stop offset="1" stop-color="#f3f4f6"/></linearGradient>
      <clipPath id="faceClip"><circle cx="50" cy="50" r="40"/></clipPath>
      <filter id="stk" x="-25%" y="-25%" width="150%" height="150%"><feMorphology in="SourceAlpha" operator="dilate" radius="2.6" result="d"/><feFlood flood-color="#ffffff"/><feComposite in2="d" operator="in" result="o"/><feMerge result="m"><feMergeNode in="o"/><feMergeNode in="SourceGraphic"/></feMerge><feDropShadow in="m" dx="0" dy="1.6" stdDeviation="1.4" flood-color="#000" flood-opacity="0.35"/></filter>
      ${syms}
    </defs></svg>`;
  }

  /* ---------- the cap ---------- */
  const f2 = (n) => n.toFixed(2);
  function arcs(r, gap) {
    let d = '';
    for (let k = 0; k < 4; k++) {
      const a0 = ((-90 + k * 90 + gap) * Math.PI) / 180, a1 = ((-90 + (k + 1) * 90 - gap) * Math.PI) / 180;
      d += `M${f2(50 + r * Math.cos(a0))} ${f2(50 + r * Math.sin(a0))}A${r} ${r} 0 0 1 ${f2(50 + r * Math.cos(a1))} ${f2(50 + r * Math.sin(a1))}`;
    }
    return d;
  }
  const RIM_ARCS = arcs(43.6, 27), RIM_HI = arcs(46.3, 27);
  const PLATES = [['top', 50, 12], ['right', 88, 50], ['bottom', 50, 88], ['left', 12, 50]];

  /* owner: 0 cobalt, 1 tangerine, -1 neutral (unclaimed in the pile) */
  function capSVG(card, owner) {
    const oc = owner === 0 ? 'p0' : owner === 1 ? 'p1' : 'pn';
    const tilt = (hash(card.id + card.art) % 13) - 6;
    const key = slug(card.art);
    const plates = PLATES.map(([d, x, y]) => {
      const v = card.stats[d], isS = v === E.S;
      return `<g transform="translate(${x} ${y})"><circle class="pshadow" r="12.6" cy="1.3" fill="rgba(0,0,0,0.3)"/><circle class="ring" r="12.4"/><circle r="10.7" fill="#fff" stroke="rgba(0,0,0,0.3)" stroke-width="1.1"/>${isS ? '<circle r="10.7" fill="none" stroke="#fbbf24" stroke-width="2.6"/>' : ''}<text class="digit${isS ? ' s' : ''}" dy="0.36em">${isS ? 'S' : v}</text></g>`;
    }).join('');
    return `<svg class="cap ${oc} t${card.tier}" viewBox="0 0 100 100" role="img" aria-label="${card.art}, top ${E.rankLabel(card.stats.top)}, right ${E.rankLabel(card.stats.right)}, bottom ${E.rankLabel(card.stats.bottom)}, left ${E.rankLabel(card.stats.left)}">` +
      `<circle class="band" cx="50" cy="50" r="48.7"/><circle class="rimBase" cx="50" cy="50" r="47.6"/>` +
      `<circle class="face" cx="50" cy="50" r="40.4"/>` +
      `<g clip-path="url(#faceClip)"><g transform="rotate(${tilt} 50 50)"><use href="#st-${key}" x="-2" y="-2" width="104" height="104"/></g><circle class="fade" cx="50" cy="50" r="40.4"/></g>` +
      `<circle cx="50" cy="50" r="40.4" fill="none" stroke="rgba(0,0,0,0.28)" stroke-width="1.3"/>` +
      `<path class="rimArc" d="${RIM_ARCS}" fill="none" stroke-width="6.6"/><path class="hi" d="${RIM_HI}"/>` +
      plates + `</svg>`;
  }

  /* ---------- sound (all generated, starts after the first tap) ---------- */
  const Sfx = (function () {
    let ac = null, on = true;
    function ctx() {
      if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ac = null; } }
      if (ac && ac.state === 'suspended') { try { ac.resume(); } catch (e) { /* ignore */ } }
      return ac;
    }
    function tone(f0, f1, dur, type, vol, delay) {
      if (!on) return;
      const c = ctx(); if (!c) return;
      const t0 = c.currentTime + (delay || 0);
      const o = c.createOscillator(), g = c.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(f0, t0);
      if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol || 0.15, t0 + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(c.destination);
      o.start(t0); o.stop(t0 + dur + 0.02);
    }
    return {
      set(v) { on = v; },
      place() { tone(180, 70, 0.1, 'triangle', 0.3); },
      flip(step) { tone(520 * Math.pow(1.12, step || 0), 300 * Math.pow(1.12, step || 0), 0.07, 'square', 0.07); },
      same() { tone(880, 880, 0.35, 'sine', 0.16); tone(1320, 1320, 0.35, 'sine', 0.1, 0.03); },
      tick() { tone(1100, 1100, 0.03, 'square', 0.05); },
      coin() { for (let i = 0; i < 6; i++) tone(1400 + i * 120, 1000, 0.05, 'triangle', 0.08, i * 0.12); },
      win() { [523, 659, 784, 1046].forEach((f, i) => tone(f, f, 0.2, 'triangle', 0.16, i * 0.11)); },
      draw() { tone(440, 440, 0.2, 'triangle', 0.14); tone(440, 440, 0.25, 'triangle', 0.14, 0.2); }
    };
  })();

  window.FYFI_ASSETS = { STICKER_NAMES, slug, defsHTML, capSVG, Sfx, hash };
})();
