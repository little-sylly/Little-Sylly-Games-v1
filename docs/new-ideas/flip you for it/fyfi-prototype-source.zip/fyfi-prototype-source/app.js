/* Flip You For It — alpha prototype UI. Game rules live in engine.js; this file is screens, input and the series. */
(function () {
  'use strict';
  const E = window.FYFI, A = window.FYFI_ASSETS;
  const { capSVG, Sfx, STICKER_NAMES } = A;
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ---------- settings (defaults from the brief section 7) ---------- */
  const DEF = { mode: 'quick', openHands: false, sameWall: true, wallHigh: true, plus: false, chain: false, bestOf: 3, timer: false, opponent: 'ptp', botLevel: 1, gates: true, board: 'cement', sound: true, names: ['Player 1', 'Player 2'] };
  const LEVELS = ['Easy', 'Medium', 'Hard'];
  const wallRangeOf = (s) => (s.wallHigh === false ? [1, 9] : [7, 9]);
  const rulesOf = (s) => ({ plus: !!s.plus, comboSame: !!s.chain });
  function loadSettings() {
    try {
      const j = JSON.parse(localStorage.getItem('fyfi-alpha') || '{}');
      return Object.assign({}, DEF, j, { names: Array.isArray(j.names) && j.names.length === 2 ? j.names : DEF.names.slice() });
    } catch (e) { return Object.assign({}, DEF, { names: DEF.names.slice() }); }
  }
  let settings = loadSettings();
  function saveSettings() { try { localStorage.setItem('fyfi-alpha', JSON.stringify(settings)); } catch (e) { /* storage unavailable */ } }
  function applySettings() { document.documentElement.dataset.board = settings.board; Sfx.set(settings.sound); }

  /* ---------- app state ---------- */
  let view = 'home', overlay = null, busy = false, M = null;
  let timerId = null, deadline = 0, lastTick = 0;
  const cardIndex = {};
  const lab = { runs: [], running: false, n: 1000, mode: 'quick', sameWall: true, wallHigh: true, rules: 'none', open: false, level: 1, progress: 0 };

  const TARGET = () => (M.set.bestOf === 3 ? 2 : 3);
  const isBot = (p) => !!M && M.set.opponent === 'bot' && p === 1;
  const privileged = () => (M.boutNo % 2 === 0 ? M.coinWinner : 1 - M.coinWinner);
  const name = (p) => esc(M.names[p]);
  const nameChip = (p) => `<span class="lab-p${p}">${name(p)}</span>`;
  const curPlayer = () => { const b = M.bout; return b.phase === 'draft' ? b.order[b.pickIdx] : E.turnOf(b.st); };


  /* ---------- game log (kept in this browser, exported as text) ---------- */
  const LOGKEY = 'fyfi-log';
  const BUILD = 'alpha-2';
  function loadLog() {
    try { const j = JSON.parse(localStorage.getItem(LOGKEY) || 'null'); if (j && Array.isArray(j.matches)) return j; } catch (e) { /* none */ }
    return { matches: [] };
  }
  let LOG = loadLog();
  function saveLog() {
    for (let i = 0; i < 4; i++) {
      try { localStorage.setItem(LOGKEY, JSON.stringify(LOG)); return; } catch (e) { if (LOG.matches.length > 1) LOG.matches.shift(); else return; }
    }
  }
  const logCount = () => LOG.matches.filter((m) => m.bouts.some((b) => b.rounds.some((r) => r.moves.length))).length;
  const cardStr = (c) => `${c.id}:${c.tier[0]}:${E.DIRS.map((d) => E.rankLabel(c.stats[d])).join('-')}`;
  function logMatchStart() {
    const s = M.set;
    M.log = {
      id: Date.now().toString(36), t: new Date().toISOString(), build: BUILD,
      set: { mode: s.mode, hands: s.openHands ? 'open' : 'hidden', wall: !!s.sameWall, wallRange: s.sameWall ? wallRangeOf(s).join('-') : null, plus: !!s.plus, chain: !!s.chain, bestOf: s.bestOf, timer: !!s.timer, opp: s.opponent, bot: s.opponent === 'bot' ? LEVELS[s.botLevel] : null },
      seats: s.opponent === 'bot' ? ['human', 'bot'] : ['human', 'human'], coinWinner: M.coinWinner, bouts: [], pts: [0, 0], done: false, left: false
    };
    LOG.matches.push(M.log);
    if (LOG.matches.length > 40) LOG.matches.splice(0, LOG.matches.length - 40);
    saveLog();
  }
  function logBoutStart(seed, pr, walls) {
    const bl = { n: M.boutNo + 1, seed, keys: pr.keys, rerolls: pr.rerolls, walls: walls ? E.DIRS.map((d) => walls[d]) : null, pool: pr.cards.map(cardStr), picks: [], rounds: [], res: null };
    M.log.bouts.push(bl);
    return bl;
  }
  /* A round is one placement phase: the opening round, then each Tie-Breaker. */
  function logRound() {
    const b = M.bout, st = b.st;
    b.log.rounds.push({ sd: b.sd, first: st.first, hands: [st.hands[0].map((c) => c.id), st.hands[1].map((c) => c.id)], moves: [], res: null });
    b.turnStart = Date.now();
    saveLog();
  }
  /* One line per placement. flips: [cell, s|b|c, depth] where s = Match-Up/Plus, b = plain flip, c = chain flip. */
  function logMove(b, p, cardId, cell, r, auto, info) {
    const rd = b.log.rounds[b.log.rounds.length - 1], ev = r.ev, cnt = E.boardCount(r.state);
    const mv = { p, card: cardId, cell, ms: Date.now() - (b.turnStart || Date.now()), flips: ev.flips.map((f) => [f.cell, f.kind[0], f.depth]), same: ev.sameFired ? 1 : 0, wallDec: ev.wallDecisive ? 1 : 0, wallSides: ev.wallSides, plus: ev.plusFired ? 1 : 0, combo: ev.comboCount, after: cnt };
    if (auto) mv.auto = 1;
    if (isBot(p)) { mv.bot = 1; delete mv.ms; if (info && info.depth) { mv.depth = info.depth; mv.worlds = info.worlds; } }
    rd.moves.push(mv);
    saveLog();
  }
  /* roll-up of human-versus-bot matches (and pass-the-phone ones, listed separately) */
  function logSummary() {
    const groups = {};
    for (const m of LOG.matches) {
      const key = m.set.opp === 'bot' ? `bot ${m.set.bot} · ${m.set.hands} hands · ${m.set.mode}` : `two humans · ${m.set.hands} hands · ${m.set.mode}`;
      const g = groups[key] || (groups[key] = { matches: 0, bouts: 0, humanBouts: 0, botBouts: 0, moves: 0, same: 0, wallDec: 0, combo: 0, flips: 0, boutsSame: 0, boutsWall: 0, boutsCombo: 0, autos: 0, thinkMs: 0, thinkN: 0 });
      g.matches++;
      for (const b of m.bouts) {
        let s = 0, w = 0, c = 0, any = false;
        for (const rd of b.rounds) {
          if (rd.sd) continue;
          for (const mv of rd.moves) {
            any = true; g.moves++; g.flips += mv.flips.length;
            if (mv.same) { g.same++; s++; }
            if (mv.wallDec) { g.wallDec++; w++; }
            if (mv.combo) { g.combo++; c++; }
            if (mv.auto) g.autos++;
            if (!mv.bot && mv.ms) { g.thinkMs += mv.ms; g.thinkN++; }
          }
        }
        if (!any) continue;
        g.bouts++; if (s) g.boutsSame++; if (w) g.boutsWall++; if (c) g.boutsCombo++;
        if (b.res && b.res.winner === 0) g.humanBouts++;
        if (b.res && b.res.winner === 1) g.botBouts++;
      }
    }
    const pct = (x, d) => (d ? Math.round((1000 * x) / d) / 10 : 0);
    return Object.keys(groups).map((k) => {
      const g = groups[k];
      return { setup: k, matches: g.matches, bouts: g.bouts, boutWins: `${g.humanBouts}-${g.botBouts}`, moves: g.moves, samePerMovePct: pct(g.same, g.moves), wallDecisivePerMovePct: pct(g.wallDec, g.moves), comboPerMovePct: pct(g.combo, g.moves), boutsWithSamePct: pct(g.boutsSame, g.bouts), boutsWithWallPct: pct(g.boutsWall, g.bouts), boutsWithComboPct: pct(g.boutsCombo, g.bouts), flipsPerMove: g.moves ? Math.round((100 * g.flips) / g.moves) / 100 : 0, timerAutoPlays: g.autos, avgHumanThinkSec: g.thinkN ? Math.round(g.thinkMs / g.thinkN / 100) / 10 : null };
    });
  }
  function logExportText() {
    return JSON.stringify({ app: 'Flip You For It', build: BUILD, exported: new Date().toISOString(), note: 'seat 0 = cobalt (the human when playing the bot), seat 1 = tangerine. Move flips are [cell, kind, depth]: s = Match-Up/Plus, b = plain flip, c = chain flip. Rounds with sd>0 are Tie-Breakers.', summary: logSummary(), matches: LOG.matches });
  }
  function logHTML() {
    const sum = logSummary(), n = logCount();
    const rows = sum.map((g) => `<tr><td>${esc(g.setup)}</td><td class="num">${g.matches}</td><td class="num">${g.bouts}</td><td class="num">${g.boutWins}</td><td class="num">${g.samePerMovePct}%</td><td class="num">${g.wallDecisivePerMovePct}%</td><td class="num">${g.comboPerMovePct}%</td><td class="num">${g.boutsWithSamePct}%</td><td class="num">${g.boutsWithWallPct}%</td><td class="num">${g.boutsWithComboPct}%</td></tr>`).join('');
    return `<div class="stack">
      <div class="topbar"><button class="icon-btn" data-act="home">Back</button><div class="mid">Game log</div><span style="min-width:40px"></span></div>
      <p class="muted">Every match you play here is recorded in this browser: the caps, the walls, every move, every flip. Copy the log and paste it to Claude to check the balance against real games.</p>
      ${n ? `<div class="card tablewrap"><table><thead><tr><th>Setup</th><th class="num">Matches</th><th class="num">Bouts</th><th class="num">You–Bot</th><th class="num">Same /move</th><th class="num">Wall /move</th><th class="num">Combo /move</th><th class="num">Same /bout</th><th class="num">Wall /bout</th><th class="num">Combo /bout</th></tr></thead><tbody>${rows}</tbody></table></div>
      <div class="row"><button class="btn primary" style="flex:2" data-act="log-copy">Copy log</button><button class="btn ghost" style="flex:1" data-act="log-clear">Clear</button></div>
      <div class="status small" id="logmsg" role="status"></div>
      <textarea id="logtext" readonly rows="8" style="width:100%;font:12px/1.4 ui-monospace,monospace" aria-label="Exported game log">${esc(logExportText())}</textarea>
      <p class="muted small">Same, Wall and Combo are counted in the opening round of each bout. Wall means a wall number made a Match-Up possible. If Copy does not work in your browser, tap the box, select all and copy.</p>`
      : '<div class="card"><p>No games recorded yet. Play a match and come back here.</p></div>'}
    </div>`;
  }
  async function copyLog() {
    const ta = $('#logtext'), msg = $('#logmsg'); if (!ta) return;
    const text = ta.value; let ok = false;
    try { if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(text); ok = true; } } catch (e) { ok = false; }
    if (!ok) { try { ta.focus(); ta.select(); ok = document.execCommand('copy'); } catch (e) { ok = false; } }
    if (msg) msg.textContent = ok ? `Copied ${Math.round(text.length / 1024)} KB. Paste it into your chat with Claude.` : 'Could not copy automatically. Tap the box below, select all, and copy.';
  }

  /* ---------- chalk board ---------- */
  function chalkSVG(walls) {
    const nums = walls ? [['top', 50, 7.4], ['right', 93, 50], ['bottom', 50, 92.6], ['left', 7, 50]].map(([d, x, y]) => `<text class="wallnum chalk-fill" x="${x}" y="${y}" dy="0.36em" font-size="10.5" text-anchor="middle">${walls[d]}</text>`).join('') : '';
    return `<svg class="chalk" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <filter id="asphalt" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed="4" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1.4 -0.55" result="m"/><feFlood style="flood-color:var(--speck)" result="c"/><feComposite in="c" in2="m" operator="in"/></filter>
        <filter id="chalkF" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="2" seed="3" result="w"/><feDisplacementMap in="SourceGraphic" in2="w" scale="2" xChannelSelector="R" yChannelSelector="G" result="d"/><feTurbulence type="fractalNoise" baseFrequency="1.1" numOctaves="1" seed="8" result="g"/><feColorMatrix in="g" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -2.4 1.85" result="ga"/><feComposite in="d" in2="ga" operator="in"/></filter>
      </defs>
      <rect width="100" height="100" filter="url(#asphalt)" opacity="0.5"/>
      <g class="chalk-stroke" filter="url(#chalkF)" fill="none" stroke-width="1.15" stroke-linecap="round">
        <rect x="14" y="14" width="72" height="72" rx="1.2"/><path d="M38 14V86M62 14V86M14 38H86M14 62H86"/>
      </g>
      <g filter="url(#chalkF)">${nums}</g>
    </svg>`;
  }
  function boardHTML(board, o) {
    o = o || {};
    let cells = '';
    for (let i = 0; i < 9; i++) {
      const t = board[i];
      let cls = 'cell', inner = '';
      if (t) {
        cls += ' filled';
        if (o.last === i) cls += ' last';
        inner = `<div class="capwrap${o.pop === i ? ' pop' : ''}" data-cid="${t.card.id}" data-role="board" data-owner="${t.owner}">${capSVG(t.card, t.owner)}</div>`;
      } else if (o.selCell === i) {
        cls += ' target pending';
        if (o.ghost) inner = `<div class="capwrap ghost-cap">${capSVG(o.ghost.card, o.ghost.owner)}</div>`;
      }
      cells += `<div class="${cls}" data-act="cell" data-i="${i}" role="button" aria-label="Cell ${i + 1}">${inner}</div>`;
    }
    return `<div class="tarmac">${chalkSVG(o.walls)}<div class="grid">${cells}</div></div>`;
  }

  /* ---------- home ---------- */
  function seg(key, opts) {
    return `<div class="seg" role="group">${opts.map(([v, l]) => `<button type="button" data-act="set" data-key="${key}" data-val='${JSON.stringify(v)}' aria-pressed="${settings[key] === v}">${l}</button>`).join('')}</div>`;
  }
  function homeHTML() {
    const s = settings;
    const hero = [
      { id: 'h1', art: 'Fruit Salad', tier: 'Veteran', stats: { top: 8, right: 5, bottom: 3, left: 7 } },
      { id: 'h2', art: 'Cookie Jar', tier: 'Legend', stats: { top: 10, right: 7, bottom: 3, left: 8 } },
      { id: 'h3', art: 'Cold Shoulder', tier: 'Specialist', stats: { top: 9, right: 2, bottom: 6, left: 4 } }
    ];
    return `<div class="stack">
      <div class="titlebar">
        <span class="pill alpha-tag">Alpha prototype · gameplay only</span>
        <h1 class="logo">Flip You <span class="b">For It</span></h1>
        <p class="muted">Place caps on a chalk board. Flip your opponent's caps to your colour. Most caps wins.</p>
      </div>
      <div class="hero-caps">${hero.map((c, i) => `<div class="capwrap">${capSVG(c, i === 1 ? 1 : 0)}</div>`).join('')}</div>
      <div class="card stack">
        <h2>House Rules</h2>
        <div class="setting"><div class="lbl">The Deal <span class="hint">how caps are dealt</span></div>${seg('mode', [['quick', 'Quick Deal'], ['draft', 'Swap Pile']])}
          <div class="hint">${s.mode === 'quick' ? 'Random hands. Fastest way to test the rules.' : 'Draft from a shared pile of 12. You can work out what the other side took, so hidden hands is a memory test here.'}</div></div>
        <div class="setting"><div class="lbl">Hands <span class="hint">what you can see</span></div>${seg('openHands', [[false, 'Hidden'], [true, 'Open']])}
          <div class="hint">${s.openHands ? 'Both hands are on show. Expect a lot of maths.' : 'You only see your own caps. Plays are bluffs and reads.'}</div></div>
        <div class="setting"><div class="lbl">Wall Match</div>${seg('sameWall', [[true, 'On'], [false, 'Off']])}</div>
        <div class="setting"><div class="lbl">Best Of</div>${seg('bestOf', [[3, '3 bouts'], [5, '5 bouts']])}</div>
        <div class="setting"><div class="lbl">Flip Clock <span class="hint">60 seconds a move</span></div>${seg('timer', [[false, 'Off'], [true, 'On']])}</div>
        <div class="setting"><div class="lbl">Opponent</div>${seg('opponent', [['ptp', 'Pass the phone'], ['bot', 'Play the bot']])}</div>
        ${s.opponent === 'bot'
          ? `<div class="setting"><div class="lbl">Bot skill <span class="hint">you are cobalt</span></div>${seg('botLevel', [[0, 'Easy'], [1, 'Medium'], [2, 'Hard']])}<div class="hint">${['Easy plays a random legal move.', 'Medium grabs the most caps it can each turn.', s.openHands ? 'Hard searches the whole bout and plays the best move it can find.' : 'Hard searches ahead and plays the best move it can, using only what it can see. It guesses your hidden caps.'][s.botLevel] || ''}</div></div>`
          : `<div class="setting"><div class="lbl">Names</div><div class="row" style="flex-wrap:nowrap"><input type="text" id="n0" maxlength="14" value="${esc(s.names[0])}" aria-label="Cobalt player name"><input type="text" id="n1" maxlength="14" value="${esc(s.names[1])}" aria-label="Tangerine player name"></div></div>`}
      </div>
      <button class="btn primary block" data-act="play" style="font-size:19px">Play</button>
      <div class="row"><button class="btn ghost" data-act="rules" style="flex:1">How to play</button><button class="btn ghost" data-act="lab" style="flex:1">Balance lab</button><button class="btn ghost" data-act="log" style="flex:1">Game log${logCount() ? ' (' + logCount() + ')' : ''}</button></div>
      <details class="card"><summary style="font-weight:700;cursor:pointer">Testing options</summary><div class="stack" style="margin-top:12px">
        <div class="setting"><div class="lbl">Board surface <span class="hint">open for build</span></div>${seg('board', [['cement', 'Dark cement'], ['pavement', 'Light pavement']])}</div>
        <div class="setting"><div class="lbl">Pass-the-phone gates <span class="hint">hidden hands</span></div>${seg('gates', [[true, 'On'], [false, 'Skip']])}
          <div class="hint">Skip lets one tester play both sides without handing over the phone. Hands stay hidden from the screen only by honour.</div></div>
        <div class="setting"><div class="lbl">Wall numbers <span class="hint">when Wall Match is on</span></div>${seg('wallHigh', [[true, '7 to 9'], [false, '1 to 9']])}
          <div class="hint">Walls match a cap edge that equals their number. 1 to 9 lets low edges be matched too.</div></div>
        <div class="setting"><div class="lbl">Plus <span class="hint">from the original Triple Triad</span></div>${seg('plus', [[false, 'Off'], [true, 'On']])}
          <div class="hint">If two or more touching pairs add up to the same total, every enemy cap in those pairs flips.</div></div>
        <div class="setting"><div class="lbl">Chain Match <span class="hint">from the original</span></div>${seg('chain', [[false, 'Off'], [true, 'On']])}
          <div class="hint">Caps flipped by a Match-Up also check for a Match-Up themselves (and Plus), so chains can keep matching.</div></div>
        <div class="setting"><div class="lbl">Sound</div>${seg('sound', [[true, 'On'], [false, 'Off']])}</div>
      </div></details>
      <p class="muted small">Stickers are placeholder drawings. Rules follow the gameplay spec and brief (third draft).</p>
    </div>`;
  }

  /* ---------- coin toss and package ---------- */
  function tossHTML() {
    const w = M.coinWinner, end = w === 0 ? 1800 : 1980;
    const quick = M.set.mode === 'quick';
    return `<div class="stack">
      <div class="topbar"><button class="icon-btn" data-act="leave">Leave</button><div class="mid">The Toss</div><button class="icon-btn" data-act="rules">?</button></div>
      <div class="coinstage"><div class="coin" style="--mid:${900 + (w ? 90 : 0)}deg;--end:${end}deg"><div class="face f0">${name(0)}</div><div class="face f1">${name(1)}</div></div></div>
      <div id="tossResult" class="stack" hidden style="text-align:center">
        <h2>${nameChip(w)} wins the toss</h2>
        <p class="muted">${quick ? `${name(w)} places first in the first bout. The seats swap each bout after that.` : `${name(w)} chooses how to play the first bout. The seats swap each bout after that.`}</p>
        <button class="btn primary block" data-act="toss-next">${quick ? 'Deal the caps' : 'Call it'}</button>
      </div></div>`;
  }
  function packageHTML() {
    const p = privileged();
    return `<div class="stack">
      <div class="topbar"><button class="icon-btn" data-act="leave">Leave</button><div class="mid">Bout ${M.boutNo + 1} · Call It</div><button class="icon-btn" data-act="rules">?</button></div>
      <h2 style="text-align:center">${nameChip(p)} calls it</h2>
      <p class="muted" style="text-align:center">${isBot(p) ? 'The bot is choosing…' : 'Pick one package. The other player gets the opposite.'}</p>
      <button class="btn block" data-act="package" data-pkg="A" style="text-align:left" ${isBot(p) ? 'disabled' : ''}><b>Pick first, place second</b><br><span class="muted small" style="font-weight:500">You keep a Pocket Cap that scores a point, so 5 of the 9 board caps wins.</span></button>
      <button class="btn block" data-act="package" data-pkg="B" style="text-align:left" ${isBot(p) ? 'disabled' : ''}><b>Pick second, place first</b><br><span class="muted small" style="font-weight:500">You make the last move of the bout, but you need 6 of the 9 board caps.</span></button>
    </div>`;
  }

  /* ---------- the pile (draft) ---------- */
  function miniHand(p, cards, label) {
    const slots = [];
    for (let i = 0; i < 5; i++) {
      const c = cards[i];
      slots.push(c ? `<div class="slot" data-cid="${c.id}" data-role="mini" data-owner="${p}"><div class="capwrap">${capSVG(c, p)}</div></div>` : '<div class="empty"></div>');
    }
    return `<div class="stack" style="gap:6px"><div class="hand-label"><b>${label}</b></div><div class="minihand">${slots.join('')}</div></div>`;
  }
  function draftHTML() {
    const b = M.bout, p = b.order[b.pickIdx], n = b.pickIdx + 1;
    const sel = overlay && overlay.type === 'pick' ? overlay.id : null;
    const hide = !b.open, viewer = M.set.opponent === 'bot' ? 0 : p;
    const pile = b.pool.map((c) => {
      const t = b.takenBy[c.id];
      const taken = t !== undefined;
      const own = taken && !hide ? t : -1;
      return `<div class="slot${taken ? ' taken' : ''}${sel === c.id ? ' sel' : ''}" data-cid="${c.id}" data-role="pile" data-owner="${own}"><div class="capwrap">${capSVG(c, own)}</div><span class="tierlab">${c.tier}</span></div>`;
    }).join('');
    const lbl = (q) => `${name(q)}${b.firstPicker === q ? ' · picks first, places second' : ' · picks second, places first'}`;
    const hands = hide
      ? `${miniHand(viewer, b.hands[viewer], M.set.opponent === 'bot' ? 'Your picks' : `${name(viewer)}'s picks`)}<p class="muted small" style="text-align:center">${name(1 - viewer)} has ${b.hands[1 - viewer].length} caps. Hands are hidden, so keep track of what leaves the pile. ${b.firstPicker === viewer ? 'You pick first and place second.' : 'You pick second and place first.'}</p>`
      : `${miniHand(0, b.hands[0], lbl(0))}${miniHand(1, b.hands[1], lbl(1))}`;
    return `<div class="stack">
      <div class="topbar"><button class="icon-btn" data-act="leave">Leave</button><div class="mid">Bout ${M.boutNo + 1} · The Swap Pile<br><span class="muted">Bouts won ${M.pts[0]}–${M.pts[1]}</span></div><button class="icon-btn" data-act="rules">?</button></div>
      <div class="status" style="font-size:17px">${isBot(p) ? `${nameChip(p)} is picking…` : `${nameChip(p)}, pick a cap`} <span class="muted small">(pick ${n} of 10)</span> ${M.set.timer && !isBot(p) ? '<span class="pill" id="clock">1:00</span>' : ''}</div>
      ${handoverBar()}
      <div class="pile">${pile}</div>
      <p class="muted small" style="text-align:center">Tap a cap to pick it. Press and hold to look closer. Two stay in the pile.</p>
      ${hands}
    </div>`;
  }
  function handoverBar() {
    const b = M.bout;
    if (!b.gate || b.gate.passed || M.set.opponent !== 'ptp' || !M.set.gates) return '';
    if (!b.open && b.phase === 'play') return '';
    return `<div class="handover"><span>Hand the phone to <b>${name(b.gate.player)}</b></span><button class="btn small" data-act="gate-pass">Ready</button></div>`;
  }

  /* ---------- the board screen ---------- */
  function playHTML() {
    const b = M.bout, st = b.st;
    const board = b.anim ? b.anim.board : st.board;
    const cnt = [0, 0];
    board.forEach((t) => { if (t) cnt[t.owner]++; });
    const first = st.first, second = 1 - first;
    const over = E.isOver(st);
    const p = over ? -1 : E.turnOf(st);
    const viewer = M.set.opponent === 'bot' ? 0 : (p >= 0 ? p : 0);
    const hand = st.hands[viewer];
    const gated = !over && M.set.opponent === 'ptp' && M.set.gates && !b.open && b.gate && !b.gate.passed;
    const sel = b.sel;
    const ghost = sel.cell !== null && sel.cardId ? { card: cardIndex[sel.cardId], owner: viewer } : null;
    const canAct = !over && !busy && !isBot(p) && !gated && !b.reopen;

    const chip = (q) => {
      const live = cnt[q] + (q === second ? 1 : 0);
      return `<div class="pchip p${q}${p === q ? ' on' : ''}${q === 1 ? ' right' : ''}"><span class="nm"><span class="dot p${q}"></span><span>${name(q)}</span></span><span class="sc">${live}</span><span class="sub">${q === first ? 'Places first' : 'Places second · +1 Pocket Cap'}</span></div>`;
    };
    let status;
    if (b.reopen) status = 'Bout over. Have a look at the board.';
    else if (over) status = 'Counting caps…';
    else if (busy) status = '&nbsp;';
    else if (isBot(p)) status = `${nameChip(p)} is thinking…`;
    else if (gated) status = `Pass the phone to ${nameChip(p)}`;
    else if (sel.cell !== null && sel.cardId) status = 'Tap the same cell again to place.';
    else if (sel.cardId) status = 'Now tap a cell.';
    else if (sel.cell !== null) status = 'Now tap a cap from your hand.';
    else status = `${nameChip(p)}'s turn. Pick a cap, then a cell.`;

    let tray;
    if (b.reopen) tray = '<button class="btn primary block" data-act="reopen">Continue</button>';
    else if (over) tray = '';
    else if (gated) tray = `<div class="gate"><h3>Pass to ${name(p)}</h3><p class="muted small">Hands are hidden. Only ${name(p)} should look.</p><button class="btn primary" data-act="gate-pass">I'm ${name(p)}</button></div>`;
    else {
      const slots = hand.map((c) => `<div class="slot${sel.cardId === c.id ? ' cap-selected' : ''}${viewer === second && hand.length === 1 ? ' pocket' : ''}" data-cid="${c.id}" data-role="hand" data-owner="${viewer}"><div class="capwrap">${capSVG(c, viewer)}</div></div>`).join('');
      tray = `<div class="hand-label"><b>${isBot(p) || M.set.opponent === 'bot' ? 'Your hand' : `${name(viewer)}'s hand`}</b><span class="muted small">${hand.length} left</span></div><div class="tray${canAct ? '' : ' dim'}">${slots}</div>
        <button class="btn primary block" data-act="place" ${canAct && sel.cell !== null && sel.cardId ? '' : 'disabled'}>Place cap</button>`;
    }
    let openRow = '';
    if (b.open && !over && !b.reopen) {
      const other = 1 - viewer;
      openRow = miniHand(other, st.hands[other], `${name(other)}'s hand (open)`);
    }
    return `<div class="stack">
      <div class="topbar"><button class="icon-btn" data-act="leave">Leave</button>
        <div class="mid">Bout ${M.boutNo + 1}${b.sd ? ` · Tie-Breaker ${b.sd}` : ''}<br><span class="muted">Bouts won ${M.pts[0]}–${M.pts[1]} · first to ${TARGET()}</span></div>
        <button class="icon-btn" data-act="rules">?</button></div>
      <div class="scorebar">${chip(0)}<div class="clock">${M.set.timer && !over ? '<span class="pill" id="clock">1:00</span>' : ''}</div>${chip(1)}</div>
      ${boardHTML(board, { walls: st.walls, selCell: sel.cell, ghost, last: b.last ? b.last.cell : -1, pop: b.anim ? b.anim.cell : -1 })}
      <div class="status" id="status">${status}</div>
      ${!gated && !b.reopen ? handoverBar() : ''}
      ${tray}
      ${openRow}
    </div>`;
  }

  /* ---------- final tally ---------- */
  function finalHTML() {
    const w = M.pts[0] > M.pts[1] ? 0 : 1;
    const snap = M.lastBoard ? `<div class="tarmac" style="max-width:260px;margin:0 auto">${chalkSVG(null)}<div class="grid">${M.lastBoard.map((t) => `<div class="cell">${t ? `<div class="capwrap">${capSVG(t.card, t.owner)}</div>` : ''}</div>`).join('')}</div></div>` : '';
    const scores = M.boutScores.map((s, i) => `<tr><td>Bout ${i + 1}</td><td class="num">${s.score[0]} – ${s.score[1]}</td><td>${s.winner < 0 ? 'Shared draw. Caps split.' : `${name(s.winner)}${s.sd ? ` (after ${s.sd} tie-breaker${s.sd > 1 ? 's' : ''})` : ''}`}</td></tr>`).join('');
    return `<div class="stack">
      <p class="eyebrow" style="text-align:center">Final Tally</p>
      <h2 style="text-align:center;font-size:30px">${nameChip(w)} wins the match</h2>
      <div class="result-score">${M.pts[0]} – ${M.pts[1]}</div>
      ${snap}
      <div class="tablewrap card"><table><thead><tr><th>Bout</th><th class="num">Caps</th><th>Won by</th></tr></thead><tbody>${scores}</tbody></table></div>
      <div class="row between card"><span>Biggest Chain Reaction</span><b>${M.stats.biggest} caps</b></div>
      <div class="row between card"><span>Caps flipped</span><b>${M.stats.flips}</b></div>
      <button class="btn primary block" data-act="rematch">Rematch</button>
      <div class="row"><button class="btn ghost" style="flex:1" data-act="home">House Rules</button><button class="btn ghost" style="flex:1" data-act="home">Leave</button></div>
    </div>`;
  }

  /* ---------- balance lab ---------- */
  function labHTML() {
    const rows = lab.runs.map((r) => {
      const pc = (x, d) => (d ? (100 * x / d) : 0);
      const fw = pc(r.firstWins, r.n);
      return `<tr><td>${r.label}</td><td class="num">${r.n}</td>
        <td><div class="bar" title="first placer wins ${fw.toFixed(1)}%"><i style="width:${Math.min(100, fw)}%"></i><b></b></div></td>
        <td class="num"><b>${fw.toFixed(1)}%</b></td><td class="num">${pc(r.secondWins, r.n).toFixed(1)}%</td><td class="num">${pc(r.draws, r.n).toFixed(1)}%</td>
        <td class="num">${pc(r.initialTies, r.n).toFixed(1)}%</td><td class="num">${pc(r.firstScoreSum, r.n * 10).toFixed(1)}%</td>
        <td class="num">${pc(r.sameBouts, r.n).toFixed(1)}%</td><td class="num">${r.wallOn ? pc(r.wallBouts, r.n).toFixed(1) + '%' : '–'}</td><td class="num">${pc(r.comboBouts, r.n).toFixed(1)}%</td><td class="num">${pc(r.sameEvents, r.placements).toFixed(1)}%</td><td class="num">${r.wallOn ? pc(r.wallEvents, r.placements).toFixed(1) + '%' : '–'}</td>
        <td class="num">${(r.flips / Math.max(1, r.placements)).toFixed(2)}</td><td class="num">${pc(r.poolsRerolled, r.n).toFixed(1)}%</td><td class="num">${r.deals ? pc(r.dealsRedealt, r.deals).toFixed(1) + '%' : '–'}</td></tr>`;
    }).join('');
    const opt = (id, val, list) => `<select id="${id}">${list.map(([v, l]) => `<option value="${v}"${String(val) === String(v) ? ' selected' : ''}>${l}</option>`).join('')}</select>`;
    return `<div class="stack">
      <div class="topbar"><button class="icon-btn" data-act="home">Back</button><div class="mid">Balance lab</div><span style="min-width:40px"></span></div>
      <p class="muted">Bots play thousands of bouts using the same engine and pool generator as the game. Both sides use the same skill, so any gap between the first and second placer comes from the rules, not the players.</p>
      <div class="card stack">
        <div class="row"><div class="setting" style="flex:1;min-width:130px"><div class="lbl">Mode</div>${opt('lab-mode', lab.mode, [['quick', 'Quick Deal'], ['draft', 'Swap Pile']])}</div>
          <div class="setting" style="flex:1;min-width:130px"><div class="lbl">Wall Match</div>${opt('lab-wall', lab.sameWall, [[true, 'On'], [false, 'Off']])}</div>
          <div class="setting" style="flex:1;min-width:130px"><div class="lbl">Wall numbers</div>${opt('lab-wallhigh', lab.wallHigh, [[true, '7 to 9'], [false, '1 to 9']])}</div></div>
        <div class="row"><div class="setting" style="flex:1;min-width:130px"><div class="lbl">Extra rules</div>${opt('lab-rules', lab.rules, [['none', 'None'], ['plus', 'Plus'], ['chain', 'Chain Match'], ['both', 'Plus + Chain']])}</div>
          <div class="setting" style="flex:1;min-width:130px"><div class="lbl">Bots see hands</div>${opt('lab-open', lab.open, [[false, 'Hidden'], [true, 'Open']])}</div></div>
        <div class="row"><div class="setting" style="flex:1;min-width:130px"><div class="lbl">Bot skill</div>${opt('lab-level', lab.level, [[0, 'Easy (random)'], [1, 'Medium (greedy)'], [2, 'Hard (search, slow)']])}</div>
          <div class="setting" style="flex:1;min-width:130px"><div class="lbl">Bouts</div>${opt('lab-n', lab.n, [[500, '500'], [1000, '1,000'], [3000, '3,000'], [10000, '10,000']])}</div></div>
        <button class="btn primary block" data-act="lab-run" ${lab.running ? 'disabled' : ''}>${lab.running ? 'Running…' : 'Run simulation'}</button>
        <div class="meter" aria-hidden="true"><i id="lab-meter" style="width:${lab.progress}%"></i></div>
      </div>
      ${rows ? `<div class="card tablewrap"><table><thead><tr><th>Setup</th><th class="num">Bouts</th><th>First placer wins</th><th class="num">%</th><th class="num">Second</th><th class="num">Draw</th><th class="num">5–5</th><th class="num">1st score</th><th class="num">Same</th><th class="num">Wall</th><th class="num">Combo</th><th class="num">Same /move</th><th class="num">Wall /move</th><th class="num">Flips/move</th><th class="num">Pool re-roll</th><th class="num">Re-deal</th></tr></thead><tbody>${rows}</tbody></table></div>
        <button class="btn ghost" data-act="lab-clear">Clear results</button>` : '<p class="muted">No runs yet. Pick a setup and run it.</p>'}
      <div class="card stack small">
        <b>Reading the table</b>
        <p><b>First placer wins</b> counts the bout winner after any Tie-Breaker rounds. The line on the bar marks 50%, the target in the spec. <b>1st score</b> is the first placer's share of the 10 points at the end of the opening round.</p>
        <p><b>Same /move</b> and <b>Wall /move</b> are the share of placements that fired a Match-Up, and the share where the wall number was needed to make it. <b>Hard</b> bots search the game tree, so they run at a few bouts a second.</p>
        <p><b>5–5</b> is how often the opening round tied and went to Sudden Death. <b>Same</b>, <b>Wall</b> and <b>Combo</b> show the share of bouts where each rule flipped something (Wall means the wall number made the Same match possible). <b>Flips/move</b> is the average caps flipped per placement.</p>
        <p><b>Pool re-roll</b> is the share of pools the generator threw away and rebuilt to pass the key-number, S-cap and answer checks. <b>Re-deal</b> is the same for the fair-deal rule in Quick Deal.</p>
        <p>Whole best-of-3 and best-of-5 matches are not simulated yet. Seats swap every bout, so the series result follows from the per-bout numbers.</p>
      </div>
    </div>`;
  }
  async function runLab() {
    if (lab.running) return;
    const rules = { plus: lab.rules === 'plus' || lab.rules === 'both', comboSame: lab.rules === 'chain' || lab.rules === 'both' };
    const opts = { mode: lab.mode, sameWall: lab.sameWall, level: lab.level, wallRange: wallRangeOf(lab), rules, open: lab.open, nodes: 8000, samples: 3 };
    const label = `${lab.mode === 'quick' ? 'Quick' : 'Draft'} · ${LEVELS[lab.level]} bots · ${lab.mode === 'draft' || lab.open ? 'open' : 'hidden'} hands · wall ${lab.sameWall ? wallRangeOf(lab).join('–') : 'off'}${rules.plus ? ' · Plus' : ''}${rules.comboSame ? ' · Chain' : ''}`;
    lab.running = true; lab.progress = 0; render();
    const chunk = lab.level === 2 ? 2 : 150;
    const tot = {};
    let done = 0;
    const seed0 = (Math.random() * 1e9) >>> 0;
    while (done < lab.n) {
      const c = Math.min(chunk, lab.n - done);
      const r = E.simulateBouts(opts, seed0 + done, c, STICKER_NAMES);
      for (const k in r) tot[k] = (tot[k] || 0) + r[k];
      done += c;
      lab.progress = (100 * done) / lab.n;
      const m = $('#lab-meter'); if (m) m.style.width = lab.progress + '%';
      await wait(0);
    }
    tot.label = label; tot.wallOn = lab.sameWall;
    lab.runs.unshift(tot);
    lab.running = false;
    if (view === 'lab') render();
  }

  /* ---------- overlays ---------- */
  const rulesHTML = () => { const rs = M ? M.set : settings, wr = wallRangeOf(rs); return `<div class="rules">
    <h2>How to play</h2>
    <div class="step"><h3>The goal</h3><p>Finish with more caps in your colour than your opponent. Each player gets 5 caps. The first placer plays all 5. The second placer plays 4 and keeps one in their pocket, which still scores a point.</p></div>
    <div class="step"><h3>Reading a cap</h3><p>Four numbers, one per edge. Higher beats lower. S is the top rank and beats 9.</p><div class="ranks"><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span><span>7</span><span>8</span><span>9</span><span class="s">S</span></div></div>
    <div class="step"><h3>Placing</h3><p>Pick a cap and a cell, then tap the cell again to place it. Any touching enemy cap with a lower number on the touching edge flips to your colour. Equal numbers do nothing on their own.</p></div>
    <div class="step"><h3>Match-Up (Same)</h3><p>If two or more of your placed cap's edges match the touching edges next to it (S matches S), every matching enemy cap flips. Your own caps count as matches too, but at least one enemy cap has to be among them.</p></div>
    <div class="step"><h3>Wall Match</h3><p>With Wall Match on, each wall carries a number from ${wr[0]} to ${wr[1]}. An edge facing a wall matches if it equals that number. An S edge matches any wall. A wall counts as one match toward the two you need, and it never flips.</p></div>
    <div class="step"><h3>Chain Reaction (Combo)</h3><p>Caps flipped by a Match-Up now act as if they were just placed. They flip any enemy cap beside them with a lower touching number, and those flips continue the chain. Chains use plain higher-beats-lower only.</p>
      <svg viewBox="0 0 300 64" role="img" aria-label="A placed cap flips two caps by Match-Up, and one of those flips a third" style="width:100%;max-width:320px">
        <defs><marker id="arw" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10z" style="fill:var(--ink)"/></marker></defs>
        <circle cx="34" cy="30" r="22" style="fill:var(--brand)"/><circle cx="116" cy="30" r="22" style="fill:var(--brand)"/><circle cx="198" cy="30" r="22" style="fill:var(--brand)"/><circle cx="270" cy="30" r="22" style="fill:var(--brand)"/>
        <path d="M58 30H90M140 30H172M222 30H244" style="stroke:var(--ink)" stroke-width="2.4" marker-end="url(#arw)" fill="none"/>
        <g font-size="11" font-weight="700" text-anchor="middle" style="fill:var(--on-brand)"><text x="34" y="34">placed</text><text x="116" y="34">Same</text><text x="198" y="34">Same</text><text x="270" y="34">Combo</text></g>
      </svg></div>
    <div class="step"><h3>Quick Deal and Swap Pile</h3><p><b>Quick Deal:</b> 5 random caps each. <b>Swap Pile:</b> 12 caps are laid out. The toss winner chooses to pick first and place second, or pick second and place first. Then you snake-draft 5 each.</p></div>
    <div class="step"><h3>Hidden or open hands</h3><p>Hands are hidden by default: you only see your own caps and have to read the other side. The Open Hands setting shows both. In the Swap Pile you can still work out what the other side took by watching the pile, so hidden hands there is a memory test.</p></div>${rs.plus || rs.chain ? `<div class="step"><h3>Testing rules</h3>${rs.plus ? '<p><b>Plus:</b> add the placed cap\'s edge to the touching edge for each neighbour. If two or more sums match, every enemy cap in those pairs flips (walls do not count).</p>' : ''}${rs.chain ? '<p><b>Chain Match:</b> caps flipped by a Match-Up (or Plus) also check for a Match-Up (or Plus) themselves, on top of the usual higher-beats-lower chain.</p>' : ''}</div>` : ''}
    <div class="step"><h3>Winning and Scoring</h3><p>Your score is your caps on the board plus 1 for the pocket cap if you placed second. The two scores always add to 10. 6 wins. A 5–5 tie goes to a Tie-Breaker Bout: the board clears, each player takes the caps in their colour, and the seats swap. After two tied Tie-Breakers the bout is a shared draw. A match is won by taking 2 bouts (best of 3) or 3 bouts (best of 5).</p></div>
    <div class="step"><h3>✨ Sylly Mode</h3><p class="muted">Not available yet.</p></div>
  </div>`; };

  function inspectHTML(o) {
    const c = cardIndex[o.id];
    if (!c) return '';
    const owner = o.owner;
    const shapes = { corner: 'Corner Anchor', spike: 'Spike', shield: 'Wall / Shield', balanced: 'Balanced', trap: 'Same Trap' };
    return `<div class="panel" style="align-items:stretch">
      <div class="bigcap"><div class="capwrap">${capSVG(c, owner)}</div></div>
      <div style="text-align:center"><h2>${esc(c.art)}</h2><p class="muted">${c.tier} · total ${E.cardTotal(c)}</p></div>
      <div class="edges">${E.DIRS.map((d) => `<div><b>${E.rankLabel(c.stats[d])}</b><span>${d}</span></div>`).join('')}</div>
      <p class="muted small" style="text-align:center">Generator shape: ${shapes[c.arch] || c.arch}. Players never see this.</p>
      <button class="btn block" data-act="close-ov">Close</button></div>`;
  }
  function boutOverlayHTML() {
    const b = M.bout, r = b.result;
    const final = M.matchOver;
    const head = r.shared ? 'Shared draw' : final ? `${nameChip(r.winner)} wins the match` : `${nameChip(r.winner)} takes the bout`;
    const next = privileged();
    const nextBoutNo = M.boutNo + 2;
    const after = final ? '' : (() => {
      const nx = 1 - next; // the player who will be privileged next bout
      return M.set.mode === 'quick' ? `Next bout, ${nameChip(nx)} places first.` : `Next bout, ${nameChip(nx)} calls it.`;
    })();
    return `<div class="panel">
      <p class="eyebrow" style="text-align:center">Bout ${M.boutNo + 1}${b.sd ? ` · after ${b.sd} tie-breaker${b.sd > 1 ? 's' : ''}` : ''}</p>
      <h2 style="text-align:center;font-size:26px">${head}</h2>
      <div class="result-score"><span class="lab-p0">${r.score[0]}</span> – <span class="lab-p1">${r.score[1]}</span></div>
      <p class="muted" style="text-align:center">Caps held, pocket cap included.${r.shared ? ' Caps split.' : ''}</p>
      <div class="row between card"><span>Bouts won</span><b>${name(0)} ${M.pts[0]} – ${M.pts[1]} ${name(1)}</b></div>
      ${after ? `<p class="muted small" style="text-align:center">${after}</p>` : ''}
      <button class="btn primary block" data-act="${final ? 'to-final' : 'next-bout'}">${final ? 'Final Tally' : 'Next bout'}</button>
      <button class="btn ghost block" data-act="peek">View the board</button>
    </div>`;
  }
  function tieOverlayHTML() {
    const b = M.bout, preview = E.suddenDeath(b.st);
    return `<div class="panel">
      <p class="eyebrow" style="text-align:center">Level at 5 – 5</p>
      <h2 style="text-align:center;font-size:26px">Tie-Breaker Bout ${b.sd + 1}</h2>
      <p class="muted" style="text-align:center">The board clears. Each player takes the caps in their colour. Hands are open. ${nameChip(preview.first)} places first this time.</p>
      ${miniHand(0, preview.hands[0], name(0))}${miniHand(1, preview.hands[1], name(1))}
      <button class="btn primary block" data-act="start-sd">Start Tie-Breaker</button>
      <button class="btn ghost block" data-act="peek">View the board</button>
    </div>`;
  }
  function renderOverlay() {
    const ov = $('#ov');
    if (!overlay) { ov.innerHTML = ''; return; }
    let cls = 'center', html = '';
    switch (overlay.type) {
      case 'rules': cls = 'sheet'; html = `<div class="panel">${rulesHTML()}<button class="btn primary block" data-act="close-ov">Got it</button></div>`; break;
      case 'inspect': cls = 'sheet'; html = inspectHTML(overlay); break;
      case 'pick': {
        const c = cardIndex[overlay.id];
        html = `<div class="panel small-box"><div style="width:130px"><div class="capwrap">${capSVG(c, -1)}</div></div><div><b>${esc(c.art)}</b><div class="muted small">${c.tier}</div></div><div class="row" style="width:100%"><button class="btn primary" style="flex:1" data-act="pick-ok">Pick</button><button class="btn" style="flex:1" data-act="close-ov">Cancel</button></div></div>`;
        break;
      }
      case 'bout': html = boutOverlayHTML(); break;
      case 'tie': html = tieOverlayHTML(); break;
      case 'leave': html = `<div class="panel small-box"><h3>Leave the Playground?</h3><p class="muted small">The match ends and nothing is saved.</p><div class="row" style="width:100%"><button class="btn" style="flex:1" data-act="close-ov">Stay</button><button class="btn primary" style="flex:1" data-act="leave-ok">Leave</button></div></div>`; break;
      default: break;
    }
    ov.innerHTML = `<div class="overlay ${cls}" data-bg="1" role="dialog" aria-modal="true">${html}</div>`;
  }

  /* ---------- render ---------- */
  function render() {
    const app = $('#app');
    app.classList.toggle('wide', view === 'lab');
    const html = { home: homeHTML, toss: () => tossHTML(), package: packageHTML, draft: draftHTML, play: playHTML, final: finalHTML, lab: labHTML, log: logHTML }[view]();
    app.innerHTML = html;
    renderOverlay();
    if (view === 'toss' && M) {
      const done = M.tossDone;
      if (done) { const r = $('#tossResult'); if (r) r.hidden = false; const c = $('.coin'); if (c) c.style.animation = 'none', c.style.transform = `rotateY(${M.coinWinner === 0 ? 0 : 180}deg)`; }
    }
    updateClock();
  }

  /* ---------- timer ---------- */
  function stopTimer() { if (timerId) clearInterval(timerId); timerId = null; deadline = 0; }
  function startTimer() {
    stopTimer();
    if (!M || !M.set.timer) return;
    deadline = Date.now() + E.CONFIG.timerSeconds * 1000;
    timerId = setInterval(tickTimer, 250);
    updateClock();
  }
  function updateClock() {
    const el = $('#clock');
    if (!el) return;
    if (!deadline) { el.textContent = '1:00'; el.classList.remove('low'); return; }
    const left = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
    el.textContent = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`;
    el.classList.toggle('low', left <= 10);
  }
  function tickTimer() {
    if (!deadline || busy) return;
    const left = Math.ceil((deadline - Date.now()) / 1000);
    if (left <= 10 && left > 0 && left !== lastTick) { lastTick = left; Sfx.tick(); }
    updateClock();
    if (Date.now() >= deadline) autoPlay();
  }
  /* Spec section 11: on expiry pick a random legal option, every time, no forfeits. */
  function autoPlay() {
    const b = M && M.bout; if (!b) return;
    stopTimer();
    overlay = overlay && overlay.type === 'pick' ? null : overlay;
    if (b.phase === 'draft') {
      const c = b.avail[E.rint(Math.random, 0, b.avail.length - 1)];
      doPick(c.id);
    } else {
      const p = E.turnOf(b.st);
      const mv = E.legalMoves(b.st, p);
      const m = mv[E.rint(Math.random, 0, mv.length - 1)];
      if (b.gate) b.gate.passed = true;
      doPlace(m.cardId, m.cell, true);
    }
  }

  /* ---------- match and bout flow ---------- */
  function startMatch() {
    const set = Object.assign({}, settings, { names: settings.names.slice() });
    const names = set.opponent === 'bot' ? ['You', 'Bot'] : set.names.map((n, i) => (n || '').trim() || 'Player ' + (i + 1));
    M = { log: null, set, names, boutNo: 0, pts: [0, 0], boutScores: [], coinWinner: Math.random() < 0.5 ? 0 : 1, stats: { flips: 0, biggest: 0 }, bout: null, matchOver: false, tossDone: false, lastBoard: null };
    logMatchStart(); overlay = null; busy = false; view = 'toss'; render(); Sfx.coin();
    const m = M;
    setTimeout(() => { if (M !== m || view !== 'toss') return; m.tossDone = true; const r = $('#tossResult'); if (r) r.hidden = false; }, 1750);
  }
  function tossNext() {
    if (M.set.mode === 'quick') startBout();
    else { view = 'package'; render(); autoPackage(); }
  }
  function autoPackage() {
    const m = M, p = privileged();
    if (!isBot(p)) return;
    setTimeout(() => { if (M !== m || view !== 'package') return; startBout(Math.random() < 0.5 ? 'A' : 'B'); }, 1000);
  }
  function registerCards(cards) { cards.forEach((c) => { cardIndex[c.id] = c; }); }

  function startBout(pkg) {
    const set = M.set, priv = privileged();
    const seed = (Math.random() * 4294967296) >>> 0;
    const pr = E.generatePool(seed, STICKER_NAMES);
    registerCards(pr.cards);
    const rng = E.mulberry32(seed ^ 0x5bd1e995);
    const walls = set.sameWall ? E.rollWalls(rng, { wallRange: wallRangeOf(set) }) : null;
    const b = { pool: pr.cards, walls, sd: 0, gate: null, sel: { cardId: null, cell: null }, last: null, rng, anim: null, reopen: null, result: null, takenBy: {} };
    M.bout = b; overlay = null; busy = false;
    b.log = logBoutStart(seed, pr, walls); 
    if (set.mode === 'draft') {
      const firstPicker = pkg === 'A' ? priv : 1 - priv;
      Object.assign(b, { phase: 'draft', firstPicker, first: 1 - firstPicker, order: E.snakeOrder(firstPicker), pickIdx: 0, avail: pr.cards.slice(), hands: [[], []], open: !!set.openHands });
      view = 'draft'; render(); beginTurn();
    } else {
      const d = E.dealQuick(pr.cards, rng);
      Object.assign(b, { phase: 'play', first: priv, open: !!set.openHands, st: E.newState({ hands: d.hands, first: priv, walls, sameWall: set.sameWall, rules: rulesOf(set) }) });
      logRound(); view = 'play'; render(); beginTurn();
    }
  }

  function beginTurn() {
    const b = M.bout, m = M;
    stopTimer();
    b.sel = { cardId: null, cell: null };
    b.turnStart = Date.now();
    const p = curPlayer();
    if (isBot(p)) { b.gate = null; render(); botThink(); return; }
    if (M.set.opponent === 'ptp' && M.set.gates) b.gate = { player: p, passed: false };
    else { b.gate = null; startTimer(); }
    render();
  }
  function passGate() {
    const b = M.bout; if (!b.gate || b.gate.passed) return;
    b.gate.passed = true; b.turnStart = Date.now(); startTimer(); render();
  }

  function botThink() {
    const m = M, b = M.bout;
    setTimeout(() => {
      if (M !== m || M.bout !== b || busy || overlay && overlay.type === 'leave') return;
      const p = curPlayer(), lvl = M.set.botLevel;
      if (b.phase === 'draft') {
        doPick(E.botPick(b.avail, lvl, b.rng));
      } else {
        const s = b.st;
        // The bot only reads the human's hand when hands are open. A Swap Pile draft and a Tie-Breaker are
        // fully deducible from the board and the pile, so the bot treats those as known.
        const knows = b.open || M.set.mode === 'draft' || b.sd > 0;
        const ctx = knows ? { open: true } : { unseen: E.unseenFor(s, b.pool, p), samples: 6 };
        ctx.nodes = 50000;
        const mv = E.botMove(s, p, lvl, b.rng, ctx);
        doPlace(mv.cardId, mv.cell, false, mv);
      }
    }, 650 + Math.random() * 500);
  }

  function doPick(id) {
    const b = M.bout; if (!b || b.phase !== 'draft') return;
    const p = b.order[b.pickIdx];
    const k = b.avail.findIndex((c) => c.id === id); if (k < 0) return;
    const card = b.avail.splice(k, 1)[0];
    b.hands[p].push(card); b.takenBy[id] = p; b.pickIdx++;
    b.log.picks.push([p, id]);
    overlay = null; Sfx.place();
    if (b.pickIdx >= 10) {
      b.phase = 'play';
      b.st = E.newState({ hands: b.hands, first: b.first, walls: b.walls, sameWall: M.set.sameWall, rules: rulesOf(M.set) });
      logRound(); view = 'play'; render(); beginTurn();
    } else { beginTurn(); }
  }

  /* ---------- placing and flip animation ---------- */
  function canAct() {
    if (view !== 'play' || !M || !M.bout || busy || overlay || M.bout.reopen) return false;
    const b = M.bout; if (b.phase !== 'play' || E.isOver(b.st)) return false;
    return !isBot(E.turnOf(b.st));
  }
  function doPlace(cardId, cell, auto, info) {
    const b = M.bout, m = M;
    const p = E.turnOf(b.st);
    stopTimer(); busy = true; overlay = overlay && overlay.type === 'pick' ? null : overlay;
    const before = b.st;
    const r = E.place(before, p, cardId, cell);
    b.st = r.state; b.last = { cell, player: p }; b.sel = { cardId: null, cell: null }; b.gate = null;
    logMove(b, p, cardId, cell, r, auto, info);
    M.stats.flips += r.ev.flips.length;
    M.stats.biggest = Math.max(M.stats.biggest, r.ev.flips.length);
    const pre = before.board.slice();
    pre[cell] = { card: cardIndex[cardId], owner: p };
    b.anim = { board: pre, cell };
    view = 'play'; render(); Sfx.place();
    animateFlips(r.ev, p).then(() => {
      if (M !== m || M.bout !== b) return;
      b.anim = null; busy = false;
      if (E.isOver(b.st)) { render(); finishBout(); } else beginTurn();
    });
  }
  function flipCap(cell, toOwner) {
    return new Promise((res) => {
      const el = document.querySelector(`.cell[data-i="${cell}"] .cap`);
      if (!el || !el.animate) { res(); return; }
      const a = el.animate([{ transform: 'rotateY(0deg)' }, { transform: 'rotateY(90deg)' }], { duration: 130, easing: 'ease-in', fill: 'forwards' });
      a.onfinish = () => {
        el.classList.remove('p0', 'p1'); el.classList.add(toOwner === 0 ? 'p0' : 'p1');
        a.cancel();
        const b2 = el.animate([{ transform: 'rotateY(-90deg)' }, { transform: 'rotateY(0deg)' }], { duration: 150, easing: 'ease-out' });
        b2.onfinish = () => res();
        b2.oncancel = () => res();
      };
      a.oncancel = () => res();
    });
  }
  async function animateFlips(ev, p) {
    await wait(260);
    const steps = [];
    const same = ev.flips.filter((f) => f.kind === 'same'), basic = ev.flips.filter((f) => f.kind === 'basic');
    if (same.length) steps.push({ f: same, sfx: 'same' });
    if (basic.length) steps.push({ f: basic, sfx: 'flip' });
    const maxD = ev.flips.reduce((x, f) => (f.kind === 'combo' ? Math.max(x, f.depth) : x), 0);
    for (let d = 1; d <= maxD; d++) steps.push({ f: ev.flips.filter((f) => f.kind === 'combo' && f.depth === d), sfx: 'combo', d });
    let n = 0;
    for (const s of steps) {
      if (s.sfx === 'same') Sfx.same(); else Sfx.flip(n);
      await Promise.all(s.f.map((f) => flipCap(f.cell, p)));
      n++;
      await wait(110);
    }
    await wait(220);
  }

  function finishBout() {
    const b = M.bout, m = M;
    const o = E.outcome(b.st);
    { const rd = b.log && b.log.rounds[b.log.rounds.length - 1]; if (rd) rd.res = { score: o.score, winner: o.winner }; }
    setTimeout(() => {
      if (M !== m || M.bout !== b) return;
      if (o.winner === -1 && b.sd < E.CONFIG.maxSuddenDeath) { overlay = { type: 'tie', openedAt: Date.now() }; Sfx.draw(); render(); return; }
      b.result = { winner: o.winner, score: o.score, shared: o.winner === -1 };
      M.boutScores.push({ winner: o.winner, score: o.score, sd: b.sd });
      if (o.winner >= 0) M.pts[o.winner]++;
      M.matchOver = o.winner >= 0 && M.pts[o.winner] >= TARGET();
      M.lastBoard = b.st.board;
      b.log.res = { score: o.score, winner: o.winner, sd: b.sd };
      M.log.pts = M.pts.slice(); M.log.done = M.matchOver; saveLog();
      overlay = { type: 'bout', openedAt: Date.now() };
      if (o.winner >= 0) Sfx.win(); else Sfx.draw();
      render();
    }, 900);
  }
  function startSD() {
    const b = M.bout;
    b.sd++; b.st = E.suddenDeath(b.st); b.open = true; b.last = null; b.reopen = null; overlay = null;
    logRound(); render(); beginTurn();
  }
  function nextBout() {
    overlay = null; M.boutNo++;
    if (M.set.mode === 'draft') { view = 'package'; render(); autoPackage(); } else startBout();
  }

  /* ---------- input: taps ---------- */
  function tapHand(id) {
    if (!canAct()) return;
    const b = M.bout;
    if (b.gate && !b.gate.passed) { if (!b.open) return; passGate(); }
    b.sel.cardId = b.sel.cardId === id ? null : id;
    render();
  }
  function tapCell(i) {
    if (!canAct()) return;
    const b = M.bout; if (b.st.board[i]) return;
    if (b.gate && !b.gate.passed) { if (!b.open) return; passGate(); }
    if (b.sel.cell === i && b.sel.cardId) { doPlace(b.sel.cardId, i); return; }
    b.sel.cell = b.sel.cell === i ? null : i;
    render();
  }
  function tapPile(id) {
    if (view !== 'draft' || busy || overlay) return;
    const b = M.bout; if (b.takenBy[id] !== undefined) return;
    if (isBot(curPlayer())) return;
    if (b.gate && !b.gate.passed) passGate();
    overlay = { type: 'pick', id, openedAt: Date.now() }; render();
  }
  function showInspect(id, owner) {
    if (!cardIndex[id]) return;
    overlay = { type: 'inspect', id, owner, openedAt: Date.now() }; renderOverlay();
  }

  /* pointer handling: tap, long-press to inspect, drag from the hand onto a cell */
  let press = null, dragEl = null;
  function endDrag() { if (dragEl) { dragEl.remove(); dragEl = null; } document.querySelectorAll('.slot.spent').forEach((n) => n.classList.remove('spent')); }
  document.addEventListener('pointerdown', (e) => {
    const el = e.target.closest('[data-cid]');
    if (!el || overlay) return;
    press = { el, id: el.dataset.cid, role: el.dataset.role, x: e.clientX, y: e.clientY, dragging: false, long: false };
    press.owner = el.dataset.owner !== undefined ? +el.dataset.owner : -1;
    press.timer = setTimeout(() => { if (press && !press.dragging) { press.long = true; showInspect(press.id, press.owner); } }, 480);
  });
  document.addEventListener('pointermove', (e) => {
    if (!press) return;
    const dx = e.clientX - press.x, dy = e.clientY - press.y;
    if (!press.dragging && Math.hypot(dx, dy) > 10) {
      clearTimeout(press.timer);
      if (press.role === 'hand' && canAct() && !(M.bout.gate && !M.bout.gate.passed && !M.bout.open)) {
        press.dragging = true;
        const c = cardIndex[press.id];
        dragEl = document.createElement('div');
        dragEl.style.cssText = 'position:fixed;width:84px;height:84px;pointer-events:none;z-index:60;transform:translate(-50%,-60%);';
        dragEl.innerHTML = capSVG(c, press.owner);
        $('#drag').appendChild(dragEl);
        press.el.classList.add('spent');
      } else { press.cancelled = true; }
    }
    if (press.dragging && dragEl) { dragEl.style.left = e.clientX + 'px'; dragEl.style.top = e.clientY + 'px'; e.preventDefault(); }
  }, { passive: false });
  function releasePress(e, cancel) {
    if (!press) return;
    const p = press; press = null;
    clearTimeout(p.timer);
    if (p.dragging) {
      if (dragEl) dragEl.style.display = 'none';
      const under = !cancel && document.elementFromPoint(e.clientX, e.clientY);
      endDrag();
      const cell = under && under.closest('.cell[data-act="cell"]');
      if (cell && canAct()) {
        const i = +cell.dataset.i, b = M.bout;
        if (!b.st.board[i]) { if (b.gate && !b.gate.passed) passGate(); b.sel = { cardId: p.id, cell: i }; render(); return; }
      }
      render();
      return;
    }
    if (cancel || p.long || p.cancelled) return;
    if (p.role === 'hand') tapHand(p.id);
    else if (p.role === 'pile') tapPile(p.id);
  }
  document.addEventListener('pointerup', (e) => releasePress(e, false));
  document.addEventListener('pointercancel', (e) => releasePress(e, true));
  document.addEventListener('contextmenu', (e) => { if (e.target.closest('[data-cid]')) e.preventDefault(); });

  /* ---------- input: clicks ---------- */
  function setView(v) { view = v; overlay = null; render(); window.scrollTo(0, 0); }
  function goHome() { stopTimer(); if (M && M.log && !M.log.done) { M.log.left = true; saveLog(); } M = null; busy = false; setView('home'); }
  document.addEventListener('click', (e) => {
    const bg = e.target.closest('[data-bg]');
    if (bg && e.target === bg && overlay && ['inspect', 'rules', 'pick', 'leave'].includes(overlay.type) && Date.now() - (overlay.openedAt || 0) > 450) { overlay = null; render(); return; }
    const t = e.target.closest('[data-act]');
    if (!t) return;
    const act = t.dataset.act;
    switch (act) {
      case 'set': {
        const key = t.dataset.key, val = JSON.parse(t.dataset.val);
        settings[key] = val; saveSettings(); applySettings(); render(); break;
      }
      case 'play': startMatch(); break;
      case 'rules': overlay = { type: 'rules', openedAt: Date.now() }; renderOverlay(); break;
      case 'lab': view = 'lab'; render(); window.scrollTo(0, 0); break;
      case 'log': view = 'log'; render(); window.scrollTo(0, 0); break;
      case 'log-copy': copyLog(); break;
      case 'log-clear': LOG.matches = M && M.log ? [M.log] : []; saveLog(); render(); break;
      case 'lab-run': runLab(); break;
      case 'lab-clear': lab.runs = []; render(); break;
      case 'home': goHome(); break;
      case 'toss-next': tossNext(); break;
      case 'package': startBout(t.dataset.pkg); break;
      case 'gate-pass': passGate(); break;
      case 'cell': tapCell(+t.dataset.i); break;
      case 'place': { const b = M.bout; if (canAct() && b.sel.cardId && b.sel.cell !== null) doPlace(b.sel.cardId, b.sel.cell); break; }
      case 'pick-ok': { if (overlay && overlay.type === 'pick') doPick(overlay.id); break; }
      case 'close-ov': overlay = null; render(); break;
      case 'leave': overlay = { type: 'leave', openedAt: Date.now() }; renderOverlay(); break;
      case 'leave-ok': goHome(); break;
      case 'next-bout': nextBout(); break;
      case 'to-final': overlay = null; view = 'final'; render(); window.scrollTo(0, 0); break;
      case 'start-sd': startSD(); break;
      case 'peek': { const b = M.bout; b.reopen = overlay; overlay = null; render(); break; }
      case 'reopen': { const b = M.bout; overlay = b.reopen; b.reopen = null; if (overlay) overlay.openedAt = Date.now(); render(); break; }
      case 'rematch': startMatch(); break;
      default: break;
    }
  });
  document.addEventListener('input', (e) => {
    const t = e.target;
    if (t.id === 'n0' || t.id === 'n1') { settings.names[+t.id.slice(1)] = t.value; saveSettings(); }
  });
  document.addEventListener('change', (e) => {
    const t = e.target;
    if (t.id === 'lab-mode') lab.mode = t.value;
    else if (t.id === 'lab-wall') lab.sameWall = t.value === 'true';
    else if (t.id === 'lab-level') lab.level = +t.value;
    else if (t.id === 'lab-wallhigh') lab.wallHigh = t.value === 'true';
    else if (t.id === 'lab-rules') lab.rules = t.value;
    else if (t.id === 'lab-open') lab.open = t.value === 'true';
    else if (t.id === 'lab-n') lab.n = +t.value;
  });

  /* ---------- boot ---------- */
  $('#defs').innerHTML = A.defsHTML();
  applySettings();
  render();
  window.FYFI_APP = { get M() { return M; }, get view() { return view; }, get LOG() { return LOG; }, render, cardIndex, chalkSVG, logExportText };
})();
