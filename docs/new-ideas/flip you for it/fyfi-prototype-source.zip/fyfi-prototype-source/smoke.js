const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const html = fs.readFileSync('test-page.html', 'utf8');

async function session(label, settings, opts) {
  const errors = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', (e) => errors.push('jsdomError: ' + (e.detail && e.detail.stack || e.message)));
  vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));
  const dom = new JSDOM(html, {
    runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://example.test/', virtualConsole: vc,
    beforeParse(w) {
      const orig = w.setTimeout.bind(w);
      w.setTimeout = (fn, ms, ...a) => orig(fn, Math.max(0, (ms || 0) * 0.02), ...a);
      w.localStorage.setItem('fyfi-alpha', JSON.stringify(settings));
      w.scrollTo = () => {};
    }
  });
  const w = dom.window, d = w.document;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const click = (el) => el.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  const press = (el) => {
    el.dispatchEvent(new w.MouseEvent('pointerdown', { bubbles: true, clientX: 5, clientY: 5 }));
    el.dispatchEvent(new w.MouseEvent('pointerup', { bubbles: true, clientX: 5, clientY: 5 }));
  };
  const $ = (s) => d.querySelector(s);
  const $$ = (s) => Array.from(d.querySelectorAll(s));
  const app = () => w.FYFI_APP;
  const waitFor = async (fn, what, ms = 8000) => {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) { try { const v = fn(); if (v) return v; } catch (e) { /* retry */ } await sleep(10); }
    throw new Error(`[${label}] timed out waiting for: ${what}. view=${app().view} text="${(d.querySelector('#status') || {}).textContent}"`);
  };

  click($('[data-act="play"]'));
  await waitFor(() => app().view === 'toss', 'toss view');
  click($('[data-act="toss-next"]'));
  let bouts = 0, moves = 0, picks = 0, sds = 0;
  for (let guard = 0; guard < 4000; guard++) {
    await sleep(8);
    const v = app().view;
    if (process.env.DBG && guard % 50 === 0) console.log(label, guard, v, JSON.stringify(((d.querySelector('#status')||{}).textContent)||''), 'ov=', !!$('#ov .overlay'), 'moves', moves);
    if (v === 'final') break;
    if (v === 'package') {
      const b = $('[data-act="package"]:not([disabled])');
      if (b) click(b);
      continue;
    }
    // overlays first
    const ov = $('#ov .overlay');
    if (ov) {
      const next = $('[data-act="next-bout"]'), fin = $('[data-act="to-final"]'), sd = $('[data-act="start-sd"]'), ok = $('[data-act="pick-ok"]');
      if (ok) { click(ok); picks++; continue; }
      if (sd) { click(sd); sds++; continue; }
      if (fin) { bouts++; click(fin); continue; }
      if (next) { bouts++; click(next); continue; }
      continue;
    }
    if (v === 'draft') {
      const slot = $$('.pile .slot:not(.taken)')[0];
      const gate = $('[data-act="gate-pass"]');
      if (gate) click(gate);
      if (slot && !/picking/.test($('.status').textContent)) press(slot);
      continue;
    }
    if (v === 'play') {
      const status = ($('#status') || {}).textContent || '';
      const gate = $('[data-act="gate-pass"]');
      if (gate) { click(gate); continue; }
      if (/thinking|Counting/.test(status) || /Bout over/.test(status)) continue;
      const hand = $$('.tray .slot');
      const cell = $$('.cell[data-act="cell"]:not(.filled)')[Math.floor(Math.random() * 3) % Math.max(1, $$('.cell:not(.filled)').length)];
      if (hand.length && cell && !$('.tray.dim')) {
        press(hand[Math.floor(Math.random() * hand.length)]);
        const free = $$('.cell:not(.filled)');
        const idx = free[Math.floor(Math.random() * free.length)].dataset.i;
        click($(`.cell[data-i="${idx}"]`));
        click($(`.cell[data-i="${idx}"]`)); // second tap confirms (fresh element after re-render)
        moves++;
        await sleep(30);
      }
    }
  }
  const v = app().view;
  const M = app().M;
  let logCheck = null;
  try {
    const parsed = JSON.parse(app().logExportText());
    const last = parsed.matches[parsed.matches.length - 1];
    const movesN = last.bouts.reduce((n, b) => n + b.rounds.reduce((m, r) => m + r.moves.length, 0), 0);
    click($('[data-act="home"]')); await sleep(20);
    click($('[data-act="log"]')); await sleep(20);
    const ta = $('#logtext');
    logCheck = { matches: parsed.matches.length, movesLogged: movesN, setHands: last.set.hands, boutsLogged: last.bouts.length, summaryRows: parsed.summary.length, viewHasText: !!(ta && ta.value.length > 100), done: last.done };
    if (!ta || movesN < 5 || !last.done) errors.push('log check failed ' + JSON.stringify(logCheck));
  } catch (e) { errors.push('log check threw ' + e.message); }
  const result = { label, logCheck, finalView: v, bouts, moves, picks, sds, pts: M && M.pts, boutScores: M && M.boutScores.map((s) => s.score.join('-') + (s.sd ? `(sd${s.sd})` : '')), stats: M && M.stats, errors: errors.slice(0, 5) };
  dom.window.close();
  return result;
}

(async () => {
  const base = { mode: 'quick', sameWall: true, bestOf: 3, timer: false, opponent: 'ptp', botLevel: 1, gates: true, board: 'cement', sound: false, names: ['Mia', 'Ben'] };
  const runs = [
    ['PTP quick hidden, gates on, Bo3', Object.assign({}, base)],
    ['PTP draft hidden, wall off, Bo5', Object.assign({}, base, { mode: 'draft', sameWall: false, bestOf: 5 })],
    ['Bot quick HARD hidden, Bo3', Object.assign({}, base, { opponent: 'bot', botLevel: 2 })],
    ['Bot draft medium open, timer on', Object.assign({}, base, { opponent: 'bot', mode: 'draft', timer: true, openHands: true })],
    ['Bot quick easy, open, Plus+Chain, wall 1-9', Object.assign({}, base, { opponent: 'bot', botLevel: 0, openHands: true, plus: true, chain: true, wallHigh: false })],
    ['Bot draft HARD hidden', Object.assign({}, base, { opponent: 'bot', mode: 'draft', botLevel: 2 })]
  ];
  let bad = 0;
  for (const [label, s] of runs) {
    try {
      const r = await session(label, s);
      console.log(JSON.stringify(r));
      if (r.finalView !== 'final' || r.errors.length) bad++;
    } catch (e) { console.log('FAIL', label, e.message); bad++; }
  }
  process.exit(bad ? 1 : 0);
})();
