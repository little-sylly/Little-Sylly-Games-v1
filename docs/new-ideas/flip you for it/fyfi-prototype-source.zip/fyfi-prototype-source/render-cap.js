global.window = { FYFI: require('./engine.js') };
require('./assets.js');
const A = window.FYFI_ASSETS;
const fs = require('fs');
const { Resvg } = require('@resvg/resvg-js');
const css = fs.readFileSync('style.css', 'utf8');
const capCss = css.split('\n').filter((l) => /^\s*\.cap[ .{]/.test(l) || /^\s*\.cap\./.test(l)).join('\n');
const mk = (id, art, tier, t, r, b, l) => ({ id, art, tier, stats: { top: t, right: r, bottom: b, left: l } });
const cards = [
  [mk('a', 'Fruit Salad', 'Veteran', 8, 5, 3, 7), 0], [mk('b', 'Cookie Jar', 'Legend', 10, 7, 3, 8), 1], [mk('c', 'Cold Shoulder', 'Specialist', 9, 2, 6, 4), 0],
  [mk('d', 'Counting Sheep', 'Wildcard', 3, 4, 5, 2), 1], [mk('e', 'Natural Selection', 'Legend', 8, 8, 8, 5), 0], [mk('f', 'Pecking Order', 'Veteran', 10, 8, 5, 8), -1],
  [mk('g', 'Flawless', 'Specialist', 3, 4, 10, 3), 1], [mk('h', 'Honeycomb Hills', 'Veteran', 6, 6, 6, 5), 0], [mk('i', 'Flip You For It', 'Legend', 9, 3, 3, 9), 1],
  [mk('j', 'Great Minds', 'Specialist', 10, 2, 3, 5), 0], [mk('k', 'Late to the Party', 'Veteran', 8, 8, 8, 2), 1], [mk('l', 'Deep-Sea Deploy', 'Specialist', 8, 8, 2, 2), 0]
];
let body = '';
cards.forEach(([c, o], i) => {
  const x = 20 + (i % 6) * 150, y = 20 + Math.floor(i / 6) * 150;
  const svg = A.capSVG(c, o).replace('<svg ', `<svg x="${x}" y="${y}" width="130" height="130" `);
  body += svg;
});
const more = ['Like I\'m Five', 'Secret Signals', 'Just Enough Cooks', 'You Get It?', 'Group Therapy', 'The Bluff', 'Bailed', 'Pass', 'Net-Trace', 'Cookie Jar', 'Fruit Salad', 'Pecking Order'];
more.forEach((n, i) => {
  const c = mk('m' + i, n, 'Wildcard', 5, 5, 5, 5);
  const x = 20 + (i % 6) * 150, y = 320 + Math.floor(i / 6) * 150;
  body += A.capSVG(c, i % 2).replace('<svg ', `<svg x="${x}" y="${y}" width="130" height="130" `);
});
const out = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="920" height="620" viewBox="0 0 920 620"><style>${capCss}\n.digit{font-family:sans-serif;font-weight:bold}</style><rect width="920" height="620" fill="#444446"/>${A.defsHTML().replace(/<svg [^>]*>/, '<g>').replace('</svg>', '</g>')}${body}</svg>`;
fs.writeFileSync('caps-preview.svg', out);
const png = new Resvg(out, { font: { loadSystemFonts: true, defaultFontFamily: 'sans-serif' }, fitTo: { mode: 'width', value: 1380 } }).render().asPng();
fs.writeFileSync('caps-preview.png', png);
console.log('rendered', png.length);
