# Handoff: Little Sylly Games — party-game box lobby

## Overview
A lobby / game-picker for a box of **18 local party games** played on a phone passed around a room (one device, several people). The lobby's job: help a group choose a game fast, understand it in ~15 seconds, and start playing. The design explores how to group 18 games, how much to explain before launch, and how the shell should feel.

Everything in this bundle is **exploratory**. Nothing is locked. It is the output of a brainstorming pass, kept so it can be pressure-tested against a real codebase before another design round.

## About the design files
`Lobby Redesign.dc.html` is a **design reference written in HTML**, not production code. It is a self-contained prototype that shows intended layout, copy, states, and behavior. The task on the other side is to **recreate these designs in the target codebase's own environment** (React Native, React, Flutter, Unity UI, whatever the game ships in) using that project's existing patterns, component library, and navigation — or, if no app environment exists yet, to pick the framework that fits a phone-first party game and implement there. Do not ship the HTML.

The file uses a small component runtime (`support.js`, bundled). Markup is inline-styled; there is no stylesheet to port. Read it as a spec, not as source.

## Fidelity
**Mid-to-high fidelity on visuals, low fidelity on content.**
- Layout, color, type scale, radii, spacing and interaction states are deliberate and can be recreated closely.
- Game artwork is a **placeholder system**: a colored tile with a faint diagonal stripe field, a large emoji, and a small `ART` mark bottom-left. Real artwork drops into the same slot with no layout change.
- Copy is drafted, not final: pitch lines, 3-step "How it goes" previews, and minute estimates are paraphrases/estimates for roughly half the games and need an author pass.
- The wordmark is type-only, awaiting the real lockup.

## How to read the file
Open `Lobby Redesign.dc.html` in a browser. It is a **canvas of options**, newest turn at the top. Each option has a visible id badge (`2a`, `1b`, …) used as shorthand in review.

- **Turn 2 (top, current thinking)**
  - `2a` — **Shelves + view-mode switcher** — the current default direction.
  - `2b` — **TV / widescreen** — 1024×576 layout of the same lobby.
- **Turn 1 (earlier explorations, kept for context)**
  - `1a` — **The Dock** — utility dock + filter pills + flat game sections.
  - `1b` — **Five Shelves** — verb folders that drill into a grid. *Preferred.*
  - `1c` — **The Box** — literal tuck-box metaphor, spines you flick through.
  - `1d` — **TV mode** — first widescreen rail+pane pass.

Stated preference: **1b > 1c > 1a**, with the tile treatment from `1a`/`1c` (art tile + title + players/time) carried into `1b`. `2a` is that merge.

---

## Soft decisions (chosen, not locked)

1. **Phone is the product.** The game will overwhelmingly be played on one phone passed around. Desktop/TV is a nice-to-have, not a target.
2. **One design, two layouts.** Not two products. Same data, same shelves, same info sheet; the widescreen layout is a breakpoint (~900px), not a separate build.
3. **Games are grouped by verb, not by theme.** People ask "do we want to talk or bluff right now?" Five shelves: **Talk · Bluff · Guess + Draw · Cards · Luck**. ("Nerve" was renamed **Luck** — the category is push-your-luck.)
4. **A game may live on two shelves.** Several games (Flawless, Fruit Salad, …) appear in two folders. Any count shown to the user counts distinct games, never duplicates.
5. **Tap a game → info sheet, not launch.** The sheet carries: pitch line, player count, modes, rough length, and a 3-step "How it goes" preview, plus a Sylly Mode line. Two buttons: **Play** and **Back to the Box**.
6. **Utility lives in a top dock, not a nav bar.** Circular 44px buttons: Sound, Controller (7-tap easter-egg trigger), Skins, Word packs, Arcade (unlocked state), Profile, Search.
7. **44px minimum for every tap target.** Dock circles and filter pills are both exactly 44px.
8. **Art slots are reserved now, filled later.** Every game tile is the same square slot; the placeholder never changes the layout.
9. **Three view modes, exposed in the top bar.** This is the newest and least-tested decision:
   - **Premium ✨ — "The Cabinet"** (future default). A three.js cabinet of physical cartridges; hover/tap pops a cartridge out of its slot, it turns and loads. Currently a dark teaser card with cartridge silhouettes and a "tell me when it's ready" CTA. **Not built.**
   - **Shelves 🗂️** (current default) — the `1b` merge.
   - **TV 🖥️ / widescreen** — rail + grid + detail pane. On a phone this mode explains it needs a wider screen rather than cramming.
10. **Shelf rows preview their contents with looping art.** Category name + count on the left, an endlessly cycling strip of game art on the right, masked at both edges. Chosen over showing a fixed 4 games so the shelf never needs redesigning as games are added.
11. **Tone.** Warm, plain, a little cheeky. Playful sans (Fredoka), warm stone neutrals, one hot pink accent, per-game color. No gradients-as-decoration, no drop-shadow soup.

## Open questions for the next round
- Does the Cabinet replace the Shelves or sit alongside them? Two front doors may be one too many.
- Does the view switcher belong in the top bar at all, or in settings once Premium ships?
- Minute estimates and 3-step previews need a factual review (≈9 games are my paraphrase).
- Art direction for the tiles — the stripe placeholder sets a square, flat, high-contrast expectation.
- Does the TV detail pane need news/what's-new slots, or stay teaching-focused?
- Does the info sheet slow down repeat players? Possibly a "skip the how-to" memory.

---

## Screens

### A. Lobby — phone (`2a`, default)
- **Frame**: 390×844, background `#FAFAF9`, content column `padding: 14px 16px 40px`, `gap: 16px`.
- **Dock card**: white, `border 1px #E7E5E4`, `radius 28px`, `padding 8px`, `shadow 0 1px 2px rgba(0,0,0,.04)`. Inside: a `space-between` row of 44×44 circles (`background #F5F5F4`, `radius 22px`, emoji 17px; dimmed items use reduced opacity for locked/unlocked state). Sound sits at the right in pink `#FCE7F3`.
- **View switcher**: 3-column grid inside the dock card, track `background #F5F5F4`, `radius 20px`, `padding 4px`. Buttons `min-height 36px`, `radius 16px`, `font 600 12px Fredoka`. Selected: white fill, ink `#292524`, `shadow 0 1px 3px rgba(0,0,0,.14)`. Unselected: transparent, `#A8A29E`.
- **Title block**: "Little Sylly" `#292524` + "Games" `#EC4899`, `700 27px Fredoka`; subline `400 13px` `#78716C` that changes per view mode.
- **Shelf rows** (5): button, white, `1px #E7E5E4`, `radius 20px`, `min-height 84px`, `padding 12px 0 12px 14px`, `overflow hidden`. Left column fixed `104px`: emoji + name (`700 18px`) over "N games" (`400 11px` `#A8A29E`). Right: the looping strip. Far right: a `›` chevron `#D6D3D1`.
- **Looping strip**: track is the tile list **concatenated with itself**, `width: max-content`, `animation: marquee 22s linear infinite` translating `0 → -50%`. Tiles 52×52, `radius 14px`, game color + stripe image, emoji 26px. Container masked: `linear-gradient(90deg, transparent, #000 8px, #000 76%, transparent)`.
- **Footnote**: "Art loops forever — a new game just joins the strip."

### B. Folder open — phone
Back button (44×44 circle) + `emoji + name` header; 2-column grid, `gap 12px`. Tile: `aspect-ratio 1`, `radius 18px`, game color + stripes, emoji 44px, `ART` mark bottom-left in 7px mono. Below: name `600 13px`, meta `400 11px #A8A29E` = players + minutes. Selected tile gets a color-matched ring.

### C. Info sheet — phone
Scrim `rgba(0,0,0,.4)`; sheet 100% × 80% height, `radius 24px 24px 0 0`, `animation slideUp .28s ease-out`. Header (52px art tile, name `700 19px`, one-line what). Scroll body: chips row (`radius 14px`, white, 1px border, `600 11px`), pitch `400 15px/1.5`, "How it goes" label in the game's color, three white step cards with monospace numerals, a Sylly Mode card. Footer buttons `min-height 56px`, `radius 16px`: primary in game color, secondary `#E7E5E4` "← Back to the Box".

### D. Lobby — TV / widescreen (`2b`)
1024×576. Top bar as one pill: dock circles left, wordmark + view switcher centre, clock + sound right. Body grid `262px | 1fr | 288px`, `gap 16px`, `padding 16px 20px 20px`.
- **Rail**: shelf buttons `min-height 58px`, name + "N games" in a fixed `92px` left column, 34px art tiles to its right (static, edge-masked). Active: white fill, `1px #D6D3D1`.
- **Grid**: 4 columns, `gap 14px`, tiles as above at 36px emoji.
- **Detail pane**: white card `radius 20px`, fixed header (60px art tile + title), scrolling body (chips, pitch, steps, Sylly Mode), pinned footer with a 48px play button in the game's color.

## Interactions
- All press states: `transform: scale(0.92–0.99)` on `:active`. No hover-dependent affordances — it's a touch product.
- View switch, folder open/close, and sheet open are instant state swaps with a 200ms `fadeIn` (opacity + 6px rise); the sheet uses a 280ms `slideUp`.
- Marquee: 22s linear, infinite, no pause. **Open**: should touching a strip pause it?
- Premium card has a 4.2s `sheen` sweep (a skewed white gradient crossing the card).
- Selection is remembered per pane on TV; the phone selects on tap and immediately opens the sheet.

## State
`view` (premium | shelves | tv) · `openFolder` · `selectedGame` · `sheetGame` (null = closed) · plus per-option duplicates for the older turn-1 explorations. On TV, rail selection and grid selection are separate (`openE`, `selE`). No data fetching; the 18 games are a static list with id, name, emoji, color, players, minutes, modes, pitch, three steps, Sylly line.

## Design tokens
- **Neutrals** (warm stone): `#FAFAF9` app bg · `#F5F5F4` sunken · `#FFFFFF` surface · `#E7E5E4` border/secondary fill · `#D6D3D1` hairline/disabled ink · `#A8A29E` tertiary text · `#78716C` secondary text · `#57534E` body · `#44403C` body-strong · `#292524` ink.
- **Accent**: `#EC4899` pink, `#FCE7F3` pink tint. **Premium**: `#1C1917`→`#0C0A09` ground, `#D4A017` gold.
- **Per-game color**: each game carries its own hex, used for its tile, its ring, its section label, and its play button. Tile ink is chosen per color for contrast.
- **Radii**: 10 / 14 / 16 / 18 / 20 / 22 (circles) / 24 / 28.
- **Type**: Fredoka. 27 title · 19–20 sheet title · 18 shelf name · 15 body-large · 13.5–13 body · 11–12 meta · 9.5–10 uppercase labels (`letter-spacing .14em`). Monospace (ui-monospace/Menlo) only for step numerals and the `ART` mark.
- **Shadows**: `0 1px 2px rgba(0,0,0,.04)` cards · `0 1px 3px rgba(0,0,0,.05–.14)` raised · `0 10px 30px -12px rgba(0,0,0,.6)` premium.
- **Spacing**: 2 / 4 / 6 / 8 / 10 / 12 / 14 / 16 / 20 / 22.

## Assets
None real yet. Emoji stand in for all 18 game icons; the stripe field is a CSS repeating-linear-gradient. Fredoka is loaded from Google Fonts. Real artwork, the wordmark, and the cartridge models are all pending from the user.

## Files
- `Lobby Redesign.dc.html` — all options, turns 1 and 2.
- `support.js` — the prototype runtime. Needed only to open the HTML; nothing to port.
- `screenshots/` — 2× captures of each option, in their default state:
  - `2a-shelves-phone.png` — current default direction (view switcher + looping shelves)
  - `2b-tv-widescreen.png` — widescreen layout, 1024×576
  - `1b-five-shelves.png` — the preferred turn-1 exploration `2a` builds on
  - `1a-the-dock.png`, `1c-the-box.png`, `1d-tv-mode-first-pass.png` — earlier explorations, context only

  Screenshots show the landing state only — the folder-open grid, the info sheet, and the Premium/TV cards are reachable by clicking through the live HTML.
